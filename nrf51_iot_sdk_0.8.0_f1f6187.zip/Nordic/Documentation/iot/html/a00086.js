var a00086 =
[
    [ "addr", "a00086.html#a8e169442ce5da35cf55989d14f5f4cf6", null ],
    [ "port", "a00086.html#a9ad1912274fe7fbf74c61311e1f454f0", null ]
];