var a00046 =
[
    [ "Client", "a00045.html", [
      [ "Common module dependency and usage", "a00045.html#iot_sdk_app_udp_server_module_usage", null ],
      [ "Setup", "a00045.html#iot_sdk_app_ipv6_stack_udp_client_setup", null ],
      [ "Testing", "a00045.html#iot_sdk_app_ipv6_stack_udp_client_test", null ],
      [ "Python Server Example", "a00045.html#iot_sdk_app_ipv6_stack_udp_client_python_sample", null ],
      [ "Troubleshooting Guide", "a00045.html#iot_sdk_app_ipv6_stack_udp_client_tbg", null ]
    ] ],
    [ "Server", "a00047.html", [
      [ "Common module dependency and usage", "a00047.html#iot_sdk_app_udp_server_module_usage", null ],
      [ "Setup", "a00047.html#iot_sdk_app_ipv6_stack_udp_server_setup", null ],
      [ "Testing", "a00047.html#iot_sdk_app_ipv6_stack_udp_server_test", null ],
      [ "Python Client Example", "a00047.html#iot_sdk_app_ipv6_stack_udp_server_python_sample", null ],
      [ "Troubleshooting Guide", "a00047.html#iot_sdk_app_ipv6_stack_udp_server_tbg", null ]
    ] ]
];