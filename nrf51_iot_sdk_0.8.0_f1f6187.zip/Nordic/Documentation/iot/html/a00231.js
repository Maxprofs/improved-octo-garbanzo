var a00231 =
[
    [ "Base defined for SDK Modules", "a00232.html", "a00232" ],
    [ "Codes reserved as identification for module where the error occurred.", "a00233.html", null ],
    [ "Codes reserved as identification for IoT errors.", "a00234.html", null ],
    [ "Codes reserved as identification for common errors.", "a00235.html", null ],
    [ "Error / status codes specific to device manager.", "a00236.html", null ],
    [ "ret_code_t", "a00231.html#gaf6c20fb483036617204f12e99e0b997b", null ]
];