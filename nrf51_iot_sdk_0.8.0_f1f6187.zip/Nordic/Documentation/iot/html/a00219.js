var a00219 =
[
    [ "sntp_client_cb_param_t", "a00104.html", [
      [ "callback_data", "a00104.html#a65a64e082cae7f19a28696c03a08ba39", null ],
      [ "time_from_server", "a00104.html#a0abea2e283e46e81204d2bd6b78f69e0", null ]
    ] ],
    [ "sntp_client_init_param_t", "a00105.html", [
      [ "app_evt_handler", "a00105.html#a40dcfd1328613032494102fc7958418a", null ],
      [ "local_udp_port", "a00105.html#ae62d0fd4249063e61af41696fe325553", null ]
    ] ],
    [ "KISS_CODE_LEN", "a00219.html#gafd1f6808732289fc12b48edc193ab97f", null ],
    [ "sntp_evt_handler_t", "a00219.html#ga621e7e3f9f0eb29b05f53cd8b1cc72a7", null ],
    [ "sntp_client_init", "a00219.html#ga9237f25537470d078b458cb589708147", null ],
    [ "sntp_client_local_time_get", "a00219.html#ga4e03b8f22fd99c0e89e658481fd049d1", null ],
    [ "sntp_client_server_query", "a00219.html#ga74c0640649e18bc02466193522ca5bdc", null ],
    [ "sntp_client_timeout_process", "a00219.html#ga034a2aacb1ef3e2b173393ff08809e11", null ],
    [ "sntp_client_uninitialize", "a00219.html#gaac1dd780a4879e559cfac4614042bd0e", null ]
];