var a00201 =
[
    [ "ble_ipsp_evt_t", "a00072.html", [
      [ "evt_id", "a00072.html#a7d04e06755d977856041c56581a81e33", null ],
      [ "evt_param", "a00072.html#aeca67d8c1f8b13e8c15778817124f17e", null ],
      [ "evt_result", "a00072.html#a6dc1ba60c75c24bbda2bedb486f0e289", null ]
    ] ],
    [ "ble_ipsp_handle_t", "a00073.html", [
      [ "cid", "a00073.html#a40aa708b150a91bbbcf37f7b7da4eddf", null ],
      [ "conn_handle", "a00073.html#a789e82274d7ee73b517ee03892878593", null ]
    ] ],
    [ "ble_ipsp_init_t", "a00074.html", [
      [ "evt_handler", "a00074.html#ac6de9aac6659de98403cb77e1814ffc6", null ]
    ] ],
    [ "BLE_IPSP_INVALID_CID", "a00201.html#ga2bce3c2dffdced83fb68e33ce806b44a", null ],
    [ "BLE_IPSP_MAX_CHANNELS", "a00201.html#ga894c079664f128ad0e6622509ec92d08", null ],
    [ "BLE_IPSP_MTU", "a00201.html#gac49bd481aa34fd3d3433e1bacdbbcd75", null ],
    [ "BLE_IPSP_PSM", "a00201.html#ga86dc449a86d19aec28bcee5fad64174a", null ],
    [ "BLE_IPSP_RX_BUFFER_COUNT", "a00201.html#gad68f63fa6a3e88496e041b42cdc10998", null ],
    [ "BLE_IPSP_RX_BUFFER_SIZE", "a00201.html#gaa63249d67b119d4fb54da2ad991601a2", null ],
    [ "BLE_IPSP_RX_MPS", "a00201.html#gaf4772989e677b93c980120e08ea4ebba", null ],
    [ "ble_ipsp_evt_handler_t", "a00201.html#gaff2200363520c8c5c9d581a7040371fb", null ],
    [ "ble_ipsp_evt_type_t", "a00201.html#gaa8026f9b645aa94ce5b1850463f92842", [
      [ "BLE_IPSP_EVT_CHANNEL_CONNECTED", "a00201.html#ggaa8026f9b645aa94ce5b1850463f92842a055e8595c996d5e47b11cf954ef25c6b", null ],
      [ "BLE_IPSP_EVT_CHANNEL_DISCONNECTED", "a00201.html#ggaa8026f9b645aa94ce5b1850463f92842a695d0286dfe763710f8582fc47812177", null ],
      [ "BLE_IPSP_EVT_CHANNEL_DATA_RX", "a00201.html#ggaa8026f9b645aa94ce5b1850463f92842a1c0c180058b42b843cd59c805bc67569", null ],
      [ "BLE_IPSP_EVT_CHANNEL_DATA_TX_COMPLETE", "a00201.html#ggaa8026f9b645aa94ce5b1850463f92842a7b1c32cfafe22cdcb6d6dc2ae1eed2f1", null ]
    ] ],
    [ "ble_ipsp_disconnect", "a00201.html#gad94c32b73cd35da49b72eecd5871009c", null ],
    [ "ble_ipsp_evt_handler", "a00201.html#gad60cb41669db486fecd0496b4312b0e4", null ],
    [ "ble_ipsp_init", "a00201.html#gaf7a7a66147420dc5125bc8bee7665ec7", null ],
    [ "ble_ipsp_send", "a00201.html#gacfadf5c058c967d8658ae2faff1d5b00", null ]
];