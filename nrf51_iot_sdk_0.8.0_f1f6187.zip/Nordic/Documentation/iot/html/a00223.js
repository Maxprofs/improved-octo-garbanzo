var a00223 =
[
    [ "ipv6_addr_conf_t", "a00097.html", [
      [ "addr", "a00097.html#a4e1b140f9220d01477271983ea63d1b9", null ],
      [ "state", "a00097.html#a62bd8502817b18e48ba796ed99a36e1f", null ]
    ] ],
    [ "ipv6_data_rx_t", "a00099.html", [
      [ "p_ip_header", "a00099.html#ab2460f5f472bb34eb120b02867e18ae8", null ],
      [ "p_rx_packet", "a00099.html#a8077c31bb0d4538566f5e24555b00ddc", null ]
    ] ],
    [ "ipv6_event_param_t", "a00100.html", [
      [ "rx_event_param", "a00100.html#a639dd5892da2025697af046f2c4ff5ea", null ]
    ] ],
    [ "ipv6_event_t", "a00101.html", [
      [ "event_id", "a00101.html#ae808bb35df02d8c4ac279ef78a036b88", null ],
      [ "event_param", "a00101.html#ac6e9626157e6ad1ab6c100bcad66a2d1", null ]
    ] ],
    [ "ipv6_init_t", "a00103.html", [
      [ "event_handler", "a00103.html#a4b6ab76d2cd7b2ce84784fc39de3b9b7", null ],
      [ "p_eui64", "a00103.html#a0ae4abf8a71a512f1add0ea6738ebf87", null ]
    ] ],
    [ "ipv6_evt_handler_t", "a00223.html#ga86b88986792fc8f6b15b28738a756b94", null ],
    [ "ipv6_event_id_t", "a00223.html#ga0b4e43a4292d03fe30b71f4b5740d2b6", [
      [ "IPV6_EVT_INTERFACE_ADD", "a00223.html#gga0b4e43a4292d03fe30b71f4b5740d2b6ad6a99f1a0aa7096e3b70b8bc62c93c71", null ],
      [ "IPV6_EVT_INTERFACE_DELETE", "a00223.html#gga0b4e43a4292d03fe30b71f4b5740d2b6a68567ab5182a14f2ada23647bc158c8a", null ],
      [ "IPV6_EVT_INTERFACE_RX_DATA", "a00223.html#gga0b4e43a4292d03fe30b71f4b5740d2b6a1c62c8561a2c12417d5355228d58b44e", null ]
    ] ],
    [ "ipv6_address_find_best_match", "a00223.html#ga16cd673e46f801c7da9101c692b5ab7f", null ],
    [ "ipv6_address_remove", "a00223.html#gae7a841150151178bc21eab78091af2a7", null ],
    [ "ipv6_address_set", "a00223.html#ga39b3e2a6309827b8ff8d6454e80d798f", null ],
    [ "ipv6_init", "a00223.html#ga7b4797ec3fe13fd64a9f1e8d21f00a96", null ],
    [ "ipv6_send", "a00223.html#gab42b5c55b5d2071a102e68cff797b5e2", null ]
];