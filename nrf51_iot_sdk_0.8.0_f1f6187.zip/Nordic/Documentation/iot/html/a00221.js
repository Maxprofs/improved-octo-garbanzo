var a00221 =
[
    [ "dns6_server_param_t", "a00086.html", [
      [ "addr", "a00086.html#a8e169442ce5da35cf55989d14f5f4cf6", null ],
      [ "port", "a00086.html#a9ad1912274fe7fbf74c61311e1f454f0", null ]
    ] ],
    [ "dns6_init_t", "a00085.html", [
      [ "dns_server", "a00085.html#aae83b4ed2d409a5cacd741117c60acde", null ],
      [ "local_src_port", "a00085.html#aaa0ff49587b3edafe98e28b150646b56", null ]
    ] ],
    [ "dns6_evt_handler_t", "a00221.html#gaf70d07b7d8cc0240d328bbca0ef78b76", null ],
    [ "dns6_init", "a00221.html#gae2ef9658e0164ffd46b3d11c832ce3ad", null ],
    [ "dns6_query", "a00221.html#ga4e73e36291c3bfb580e592720364feea", null ],
    [ "dns6_timeout_process", "a00221.html#gadfcc9ffe53043e083defa81494d21874", null ],
    [ "dns6_uninit", "a00221.html#ga839447f4fefa7d2057f7c9c141748763", null ]
];