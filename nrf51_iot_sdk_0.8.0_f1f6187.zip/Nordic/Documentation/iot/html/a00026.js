var a00026 =
[
    [ "Server", "a00037.html", [
      [ "Common module dependency and usage", "a00037.html#iot_sdk_app_dtls_server_module_usage", null ],
      [ "Setup", "a00037.html#iot_sdk_app_dtls_server_setup", null ],
      [ "Testing", "a00037.html#iot_sdk_app_dtls_server_test", null ],
      [ "Troubleshooting Guide", "a00037.html#iot_sdk_app_dtls_server_tbg", null ]
    ] ],
    [ "Client", "a00036.html", [
      [ "Common module dependency and usage", "a00036.html#iot_sdk_app_dtls_client_module_usage", null ],
      [ "Setup", "a00036.html#iot_sdk_app_dtls_client_setup", null ],
      [ "Testing", "a00036.html#iot_sdk_app_dtls_client_test", null ],
      [ "Troubleshooting Guide", "a00036.html#iot_sdk_app_dtls_client_tbg", null ]
    ] ]
];