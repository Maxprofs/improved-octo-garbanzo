var a00226 =
[
    [ "COAP_CT_MASK_APP_EXI", "a00226.html#ga7b4d18542a284942e0a679fc1ecc5dfe", null ],
    [ "COAP_CT_MASK_APP_JSON", "a00226.html#gaa3c4884dc0b34a836b34beeb6d1501a4", null ],
    [ "COAP_CT_MASK_APP_LINK_FORMAT", "a00226.html#ga78a94ac1e737e659224d61ba980ac3f1", null ],
    [ "COAP_CT_MASK_APP_OCTET_STREAM", "a00226.html#gafb6cd58009301c1181451394c9315938", null ],
    [ "COAP_CT_MASK_APP_XML", "a00226.html#gac1f2d3695345b0c34d4b08816fe3bd1c", null ],
    [ "COAP_CT_MASK_CHARSET_UTF8", "a00226.html#ga772b77b0e098bfae61528c296ae61b5f", null ],
    [ "COAP_CT_MASK_PLAIN_TEXT", "a00226.html#ga7478a1526622a4f5827c0cc939732500", null ]
];