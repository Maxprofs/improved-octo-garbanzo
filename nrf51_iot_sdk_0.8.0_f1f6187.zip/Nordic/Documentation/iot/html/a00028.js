var a00028 =
[
    [ "MQTT Client - Publisher", "a00043.html", [
      [ "Common Modules Dependency and Usage", "a00043.html#iot_sdk_app_mqtt_publisher_module_usage", null ],
      [ "Setup", "a00043.html#iot_sdk_app_mqtt_publisher_setup", [
        [ "LED assignments", "a00043.html#iot_sdk_app_mqtt_publisher_setup_led", null ],
        [ "Button assignments", "a00043.html#iot_sdk_app_mqtt_publisher_setup_button", null ],
        [ "MQTT Broker Setup", "a00043.html#iot_sdk_app_mqtt_borker_setup", null ]
      ] ],
      [ "Testing", "a00043.html#iot_sdk_app_mqtt_publisher_test", [
        [ "MQTT Subscriber setup", "a00043.html#iot_sdk_app_mqtt_subsciber_setup_2", null ]
      ] ]
    ] ],
    [ "MQTT Client - Subscriber", "a00044.html", [
      [ "Common Modules Dependency and Usage", "a00044.html#iot_sdk_app_mqtt_subscriber_module_usage", null ],
      [ "Setup", "a00044.html#iot_sdk_app_mqtt_subscriber_setup", [
        [ "LED assignments", "a00044.html#iot_sdk_app_mqtt_subscriber_setup_led", null ],
        [ "Button assignments", "a00044.html#iot_sdk_app_mqtt_subscriber_setup_button", null ],
        [ "MQTT Broker Setup", "a00044.html#iot_sdk_app_mqtt_borker_setup", null ]
      ] ],
      [ "Testing", "a00044.html#iot_sdk_app_mqtt_subscriber_test", [
        [ "MQTT Publisher setup", "a00044.html#iot_sdk_app_mqtt_publisher_setup_2", null ]
      ] ]
    ] ]
];