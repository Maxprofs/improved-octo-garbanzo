var a00091 =
[
    [ "compression_flag", "a00091.html#ac698c1a4e92b32c76aeb32d294597239", null ],
    [ "context_id", "a00091.html#ab4b9f418db1963afdcb7dd5895ddbb4b", null ],
    [ "prefix", "a00091.html#a6b2efab0f3511964ab3b21dafcb758aa", null ],
    [ "prefix_len", "a00091.html#a442a4472d16b021426d9bb80abad05ee", null ]
];