var a00085 =
[
    [ "dns_server", "a00085.html#aae83b4ed2d409a5cacd741117c60acde", null ],
    [ "local_src_port", "a00085.html#aaa0ff49587b3edafe98e28b150646b56", null ]
];