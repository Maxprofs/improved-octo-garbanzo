var a00097 =
[
    [ "addr", "a00097.html#a4e1b140f9220d01477271983ea63d1b9", null ],
    [ "state", "a00097.html#a62bd8502817b18e48ba796ed99a36e1f", null ]
];