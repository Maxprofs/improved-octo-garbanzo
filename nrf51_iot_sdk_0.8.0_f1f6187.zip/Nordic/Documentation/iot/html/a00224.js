var a00224 =
[
    [ "udp6_socket_t", "a00107.html", [
      [ "p_app_data", "a00107.html#aa3c355a3e4b310ad294cfb9d6bad09dc", null ],
      [ "socket_id", "a00107.html#a57cd813df4dd11d7b473bb1ede142ca5", null ]
    ] ],
    [ "udp6_handler_t", "a00224.html#gada9cee81766469a95046fec539453d94", null ],
    [ "udp6_socket_allocate", "a00224.html#gac482bb45373e42a0be393c4c50092da5", null ],
    [ "udp6_socket_app_data_set", "a00224.html#ga3eb9d41d7d38d77b671c81c3042a680d", null ],
    [ "udp6_socket_bind", "a00224.html#gab2095655ce43e838c82ff9a5d0991b4d", null ],
    [ "udp6_socket_connect", "a00224.html#gad2642e5aa71f0c42a893c414840403e5", null ],
    [ "udp6_socket_free", "a00224.html#ga2a6076ef6f38b1315288f8c468edbe34", null ],
    [ "udp6_socket_recv", "a00224.html#ga2e2b05075ebd7d28589b931c50bbbd83", null ],
    [ "udp6_socket_send", "a00224.html#ga45e4f17016169f82467c10912c335306", null ],
    [ "udp6_socket_sendto", "a00224.html#gaa7ce624a064ec22f59c329ea46d70d9f", null ]
];