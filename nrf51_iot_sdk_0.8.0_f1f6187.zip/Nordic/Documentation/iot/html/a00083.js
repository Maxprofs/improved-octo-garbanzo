var a00083 =
[
    [ "callback", "a00083.html#a1ff7de0fe8182ff2c04309f3f19c32dd", null ],
    [ "child_count", "a00083.html#aa726de3a396645384386e3220ca99608", null ],
    [ "ct_support_mask", "a00083.html#a8d5b288b837193d1458491be6a49f7da", null ],
    [ "expire_time", "a00083.html#a0cdccda28cee555b517f129f329e9197", null ],
    [ "max_age", "a00083.html#ada7ed80d8c8fabe131b5f5108f5fb50a", null ],
    [ "name", "a00083.html#ae0f7e5fdb6fdba055efc1688fda00c7e", null ],
    [ "p_front", "a00083.html#a89d5a9c7c8c1a8defb331f90e3cfe87d", null ],
    [ "p_sibling", "a00083.html#abe331eb3786e79a817b9f8141646fe45", null ],
    [ "p_tail", "a00083.html#ae3f9dc0b129b1b81a5f009ac1490d3f3", null ],
    [ "permission", "a00083.html#a27aaef2d7880e62bf430356355c871c5", null ]
];