var a00230 =
[
    [ "coap_port_t", "a00081.html", [
      [ "port_number", "a00081.html#a885a65ebe802d4e0292c074a81070a89", null ]
    ] ],
    [ "coap_remote_t", "a00082.html", [
      [ "addr", "a00082.html#a48933525c4846624c19e8965fa002375", null ],
      [ "port_number", "a00082.html#abb615d3999359f9af2fdec3d4b5c6de2", null ]
    ] ],
    [ "coap_transport_init_t", "a00084.html", [
      [ "p_port_table", "a00084.html#a1330e22fe796bb5e7d824880c5ee533f", null ],
      [ "port_count", "a00084.html#a14a65d7ff876b0cebf6335d8ff9a3411", null ]
    ] ],
    [ "coap_transport_init", "a00230.html#gae3e28bb7371957b414a89368359c832c", null ],
    [ "coap_transport_read", "a00230.html#ga94a36e97c09b2591154f96279cf24ae4", null ],
    [ "coap_transport_write", "a00230.html#ga6fe84e75f038f498a96a62718dd8ba4f", null ]
];