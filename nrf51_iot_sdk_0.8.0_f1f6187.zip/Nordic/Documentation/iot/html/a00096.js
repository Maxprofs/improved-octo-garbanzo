var a00096 =
[
    [ "client_list_length", "a00096.html#a11564a4a0ed69b1236187330740f9f3a", null ],
    [ "p_client_list", "a00096.html#a96020ab66557b95393d76557a699afdf", null ]
];