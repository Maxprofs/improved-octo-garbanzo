var a00232 =
[
    [ "SDK_COMMON_ERROR_BASE", "a00232.html#ga1fa2dae6c4a22d6592184236f7f8ed4e", null ],
    [ "SDK_ERROR_BASE", "a00232.html#ga3756b7defda416b28928be1af33c4257", null ]
];