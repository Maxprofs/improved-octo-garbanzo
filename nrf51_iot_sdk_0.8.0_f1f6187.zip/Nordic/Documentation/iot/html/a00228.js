var a00228 =
[
    [ "coap_msg_code_t", "a00228.html#ga94f4c37162ba4eacbfe25f807b8dc4e6", null ]
];