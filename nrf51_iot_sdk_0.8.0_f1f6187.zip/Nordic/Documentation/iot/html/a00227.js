var a00227 =
[
    [ "COAP_PERM_DELETE", "a00227.html#ga432450516800ecd91303b3451d32c2e7", null ],
    [ "COAP_PERM_GET", "a00227.html#gadcaace2119b06f1f6c62f326994b218f", null ],
    [ "COAP_PERM_NONE", "a00227.html#ga25397cce0f67c13e41d0cd8e7b564317", null ],
    [ "COAP_PERM_OBSERVE", "a00227.html#gaf7ffc507cc8e999893804ee21fee8b58", null ],
    [ "COAP_PERM_POST", "a00227.html#ga67ac8ad312a24a51e929f1eddfca5559", null ],
    [ "COAP_PERM_PUT", "a00227.html#ga3284cf3bb3a6826c1ee0d16916ef940a", null ],
    [ "COAPS_PERM_DELETE", "a00227.html#gac843d773ab40c09dd686d98724fe7935", null ],
    [ "COAPS_PERM_GET", "a00227.html#ga848091859bec49dac7be304505b4143b", null ],
    [ "COAPS_PERM_POST", "a00227.html#gabf073068a999b17c649c0b4443b444ee", null ],
    [ "COAPS_PERM_PUT", "a00227.html#ga56a4c3e08ac62f6957b71ee83e074e2e", null ]
];