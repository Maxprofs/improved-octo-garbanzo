var searchData=
[
  ['sntp_5fevt_5fhandler_5ft',['sntp_evt_handler_t',['../a00219.html#ga621e7e3f9f0eb29b05f53cd8b1cc72a7',1,'sntp_client.h']]]
];
