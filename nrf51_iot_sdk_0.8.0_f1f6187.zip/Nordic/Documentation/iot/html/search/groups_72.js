var searchData=
[
  ['resource_20content_20type_20bitmask_20values',['Resource content type bitmask values',['../a00226.html',1,'']]],
  ['resource_20method_20permission_20bitmask_20values',['Resource method permission bitmask values',['../a00227.html',1,'']]]
];
