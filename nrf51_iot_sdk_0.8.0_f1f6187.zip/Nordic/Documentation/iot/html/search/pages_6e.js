var searchData=
[
  ['nordic_27s_20ipv6_20stack_20based_20udp_20examples',['Nordic&apos;s IPv6 Stack based UDP Examples',['../a00046.html',1,'iot_sdk_app_udp']]],
  ['nrf51_20iot_20sdk_20v_2e_200_2e7_2e0',['nRF51 IoT SDK v. 0.7.0',['../a00052.html',1,'iot_release_notes']]],
  ['nrf51_20iot_20sdk_20v_2e_200_2e8_2e0',['nRF51 IoT SDK v. 0.8.0',['../a00053.html',1,'iot_release_notes']]],
  ['nordic_27s_20ipv6_20stack',['Nordic&apos;s IPv6 stack',['../a00008.html',1,'lib_iot']]]
];
