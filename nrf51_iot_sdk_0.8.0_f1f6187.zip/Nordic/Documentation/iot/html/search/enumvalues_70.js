var searchData=
[
  ['pbuffer_5fflag_5fdefault',['PBUFFER_FLAG_DEFAULT',['../a00220.html#gga60561c05895d52310fcb6b3ac1822c0eac80072b794d94b670581caa6c66559d3',1,'iot_pbuffer.h']]],
  ['pbuffer_5fflag_5fno_5fmem_5fallocation',['PBUFFER_FLAG_NO_MEM_ALLOCATION',['../a00220.html#gga60561c05895d52310fcb6b3ac1822c0ea872074207701f7f645f0f9e5e010f979',1,'iot_pbuffer.h']]]
];
