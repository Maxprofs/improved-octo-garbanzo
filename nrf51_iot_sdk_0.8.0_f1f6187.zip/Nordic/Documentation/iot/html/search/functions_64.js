var searchData=
[
  ['dns6_5finit',['dns6_init',['../a00221.html#gae2ef9658e0164ffd46b3d11c832ce3ad',1,'dns6_api.h']]],
  ['dns6_5fquery',['dns6_query',['../a00221.html#ga4e73e36291c3bfb580e592720364feea',1,'dns6_api.h']]],
  ['dns6_5ftimeout_5fprocess',['dns6_timeout_process',['../a00221.html#gadfcc9ffe53043e083defa81494d21874',1,'dns6_api.h']]],
  ['dns6_5funinit',['dns6_uninit',['../a00221.html#ga839447f4fefa7d2057f7c9c141748763',1,'dns6_api.h']]]
];
