var searchData=
[
  ['kit_20setup',['Kit setup',['../a00019.html',1,'iot_cloud_coap']]],
  ['kit_20setup',['Kit setup',['../a00022.html',1,'iot_cloud_mqtt']]],
  ['kiss_5fcode_5flen',['KISS_CODE_LEN',['../a00219.html#gafd1f6808732289fc12b48edc193ab97f',1,'sntp_client.h']]]
];
