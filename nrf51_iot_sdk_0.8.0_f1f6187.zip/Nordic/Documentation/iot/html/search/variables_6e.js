var searchData=
[
  ['name',['name',['../a00083.html#ae0f7e5fdb6fdba055efc1688fda00c7e',1,'coap_resource_t']]],
  ['next_5fheader',['next_header',['../a00102.html#a0061a3ee12ef7f1c68c3febd89256262',1,'ipv6_header_t']]],
  ['number',['number',['../a00080.html#ae7c4379b2c23cb6844486dbb69d513c5',1,'coap_option_t']]]
];
