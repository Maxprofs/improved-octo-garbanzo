var searchData=
[
  ['resource_20content_20type_20bitmask_20values',['Resource content type bitmask values',['../a00226.html',1,'']]],
  ['resource_20method_20permission_20bitmask_20values',['Resource method permission bitmask values',['../a00227.html',1,'']]],
  ['release_20notes',['Release Notes',['../a00063.html',1,'']]],
  ['raw_5fpacket_5ftype',['RAW_PACKET_TYPE',['../a00220.html#gga18db6248bc0f2948d9a14ffb09b3038ea5cb8f169e8b4d4ca8ff7f77d9285b9fa',1,'iot_pbuffer.h']]],
  ['remote',['remote',['../a00077.html#a2e3559790d7b9c7cd3aad0cc7a81b139',1,'coap_message_t::remote()'],['../a00079.html#a5a13129e411c8e332ce7a8ba12531f85',1,'coap_observer_t::remote()'],['../a00078.html#a022a42f24573a3c6483a3c54498c1a00',1,'coap_observable_t::remote()']]],
  ['response_5fcallback',['response_callback',['../a00075.html#aa4addf972e495f641cd6a746061b5829',1,'coap_message_conf_t::response_callback()'],['../a00077.html#acdad4b6561911b2b1f40e1d3c2eec380',1,'coap_message_t::response_callback()'],['../a00078.html#a92bdef06bc6ff00af2de809bf0a91210',1,'coap_observable_t::response_callback()']]],
  ['ret_5fcode_5ft',['ret_code_t',['../a00231.html#gaf6c20fb483036617204f12e99e0b997b',1,'sdk_errors.h']]],
  ['rx_5fcontexts',['rx_contexts',['../a00068.html#ad836dc2ec024b6f9e0a9959e71da86eb',1,'ble_6lowpan_data_rx_t']]],
  ['rx_5fevent_5fparam',['rx_event_param',['../a00069.html#ac0671ac68c8a26c93cd973af9de89c80',1,'ble_6lowpan_event_param_t::rx_event_param()'],['../a00100.html#a639dd5892da2025697af046f2c4ff5ea',1,'ipv6_event_param_t::rx_event_param()']]]
];
