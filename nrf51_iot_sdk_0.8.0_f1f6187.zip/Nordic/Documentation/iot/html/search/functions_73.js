var searchData=
[
  ['sntp_5fclient_5finit',['sntp_client_init',['../a00219.html#ga9237f25537470d078b458cb589708147',1,'sntp_client.h']]],
  ['sntp_5fclient_5flocal_5ftime_5fget',['sntp_client_local_time_get',['../a00219.html#ga4e03b8f22fd99c0e89e658481fd049d1',1,'sntp_client.h']]],
  ['sntp_5fclient_5fserver_5fquery',['sntp_client_server_query',['../a00219.html#ga74c0640649e18bc02466193522ca5bdc',1,'sntp_client.h']]],
  ['sntp_5fclient_5ftimeout_5fprocess',['sntp_client_timeout_process',['../a00219.html#ga034a2aacb1ef3e2b173393ff08809e11',1,'sntp_client.h']]],
  ['sntp_5fclient_5funinitialize',['sntp_client_uninitialize',['../a00219.html#gaac1dd780a4879e559cfac4614042bd0e',1,'sntp_client.h']]]
];
