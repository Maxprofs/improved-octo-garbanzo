var searchData=
[
  ['sntp_5fclient_5fcb_5fparam_5ft',['sntp_client_cb_param_t',['../a00104.html',1,'']]],
  ['sntp_5fclient_5finit_5fparam_5ft',['sntp_client_init_param_t',['../a00105.html',1,'']]]
];
