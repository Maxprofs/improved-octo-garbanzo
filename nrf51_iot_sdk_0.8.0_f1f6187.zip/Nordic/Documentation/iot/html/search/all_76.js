var searchData=
[
  ['version',['version',['../a00076.html#ae1edaaa1d09c41829815ce4f01e9b464',1,'coap_message_header_t']]],
  ['version_5ftraffic_5fclass',['version_traffic_class',['../a00102.html#a7fa4f0eff3b06757e1677d2e3b1d9057',1,'ipv6_header_t']]]
];
