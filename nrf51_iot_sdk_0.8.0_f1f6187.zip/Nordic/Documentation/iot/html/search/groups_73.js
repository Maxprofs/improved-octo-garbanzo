var searchData=
[
  ['sdk_20error_20codes',['SDK Error codes',['../a00231.html',1,'']]],
  ['sntp_20client',['SNTP Client',['../a00219.html',1,'']]]
];
