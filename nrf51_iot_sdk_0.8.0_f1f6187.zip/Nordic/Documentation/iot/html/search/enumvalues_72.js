var searchData=
[
  ['raw_5fpacket_5ftype',['RAW_PACKET_TYPE',['../a00220.html#gga18db6248bc0f2948d9a14ffb09b3038ea5cb8f169e8b4d4ca8ff7f77d9285b9fa',1,'iot_pbuffer.h']]]
];
