var searchData=
[
  ['coap_5ferror_5fcallback_5ft',['coap_error_callback_t',['../a00225.html#ga797ff9ae8d2b387e1b12233b3f2f3b33',1,'coap_api.h']]],
  ['coap_5fmethod_5fcallback_5ft',['coap_method_callback_t',['../a00225.html#gacfc4b8f23e42e6c0ede0e5b5d206ed0a',1,'coap_api.h']]],
  ['coap_5fresponse_5fcallback_5ft',['coap_response_callback_t',['../a00225.html#gad24c08c7c73104aec7417f8d1cc50318',1,'coap_api.h']]]
];
