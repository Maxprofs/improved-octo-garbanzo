var searchData=
[
  ['dns6_5finit_5ft',['dns6_init_t',['../a00085.html',1,'']]],
  ['dns6_5fserver_5fparam_5ft',['dns6_server_param_t',['../a00086.html',1,'']]]
];
