var searchData=
[
  ['max_5fage',['max_age',['../a00083.html#ada7ed80d8c8fabe131b5f5108f5fb50a',1,'coap_resource_t::max_age()'],['../a00078.html#a0d28d7c83c5b2a4f4c053c49aca598e7',1,'coap_observable_t::max_age()']]]
];
