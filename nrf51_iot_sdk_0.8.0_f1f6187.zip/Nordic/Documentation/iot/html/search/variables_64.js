var searchData=
[
  ['data_5flen',['data_len',['../a00077.html#a4288bdcbc8462d53ab83482beb98b0ad',1,'coap_message_t']]],
  ['dest_5fcntxt_5fid',['dest_cntxt_id',['../a00090.html#ad441bc269c7994f31a2ee8bd9a2e2a4e',1,'iot_context_id_t']]],
  ['destaddr',['destaddr',['../a00102.html#a910acdb4b215b79be042eb5779576fa9',1,'ipv6_header_t']]],
  ['destport',['destport',['../a00106.html#aff14f7f04d1ff340ccf7b2b58991650e',1,'udp6_header_t']]],
  ['dns_5fserver',['dns_server',['../a00085.html#aae83b4ed2d409a5cacd741117c60acde',1,'dns6_init_t']]]
];
