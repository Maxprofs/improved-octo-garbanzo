var searchData=
[
  ['ntp_20codes_2e',['NTP codes.',['../a00216.html',1,'']]],
  ['nordic_27s_20ipv6_20stack_20based_20udp_20examples',['Nordic&apos;s IPv6 Stack based UDP Examples',['../a00046.html',1,'iot_sdk_app_udp']]],
  ['nordic_27s_20coap',['Nordic&apos;s CoAP',['../a00240.html',1,'']]],
  ['nrf51_20iot_20sdk_20v_2e_200_2e7_2e0',['nRF51 IoT SDK v. 0.7.0',['../a00052.html',1,'iot_release_notes']]],
  ['nrf51_20iot_20sdk_20v_2e_200_2e8_2e0',['nRF51 IoT SDK v. 0.8.0',['../a00053.html',1,'iot_release_notes']]],
  ['nordic_27s_20ipv6_20stack',['Nordic&apos;s IPv6 stack',['../a00241.html',1,'']]],
  ['nordic_27s_20ipv6_20stack',['Nordic&apos;s IPv6 stack',['../a00008.html',1,'lib_iot']]],
  ['name',['name',['../a00083.html#ae0f7e5fdb6fdba055efc1688fda00c7e',1,'coap_resource_t']]],
  ['next_5fheader',['next_header',['../a00102.html#a0061a3ee12ef7f1c68c3febd89256262',1,'ipv6_header_t']]],
  ['ntohl',['NTOHL',['../a00204.html#ga2d4ff2d1b939f36d85ac71ffb9849a85',1,'iot_defines.h']]],
  ['ntohs',['NTOHS',['../a00204.html#ga3ff27287f98eaa82eee837264fc0c161',1,'iot_defines.h']]],
  ['number',['number',['../a00080.html#ae7c4379b2c23cb6844486dbb69d513c5',1,'coap_option_t']]]
];
