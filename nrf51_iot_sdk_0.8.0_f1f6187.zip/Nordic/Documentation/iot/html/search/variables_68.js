var searchData=
[
  ['header',['header',['../a00077.html#a73db37d246997d4c92764495d9ab152f',1,'coap_message_t']]],
  ['hoplimit',['hoplimit',['../a00102.html#a5d7414d18e3081a9efe76e43c19648f3',1,'ipv6_header_t']]]
];
