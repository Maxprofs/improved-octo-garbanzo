var searchData=
[
  ['observer_20client',['Observer Client',['../a00033.html',1,'iot_sdk_app_coap']]],
  ['observable_20server',['Observable Server',['../a00035.html',1,'iot_sdk_app_coap']]]
];
