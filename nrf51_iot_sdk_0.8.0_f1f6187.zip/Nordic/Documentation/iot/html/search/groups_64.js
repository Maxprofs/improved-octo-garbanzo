var searchData=
[
  ['dns_20codes_2e',['DNS codes.',['../a00215.html',1,'']]],
  ['dns_20application_20interface_20for_20nordic_27s_20ipv6_20stack',['DNS Application Interface for Nordic&apos;s IPv6 stack',['../a00221.html',1,'']]]
];
