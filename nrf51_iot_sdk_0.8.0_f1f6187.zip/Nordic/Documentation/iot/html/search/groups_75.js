var searchData=
[
  ['udp_20codes',['UDP codes',['../a00212.html',1,'']]],
  ['udp_20application_20interface_20for_20nordic_27s_20ipv6_20stack',['UDP Application Interface for Nordic&apos;s IPv6 stack',['../a00224.html',1,'']]]
];
