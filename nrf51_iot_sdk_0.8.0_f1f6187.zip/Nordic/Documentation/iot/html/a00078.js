var a00078 =
[
    [ "max_age", "a00078.html#a0d28d7c83c5b2a4f4c053c49aca598e7", null ],
    [ "remote", "a00078.html#a022a42f24573a3c6483a3c54498c1a00", null ],
    [ "response_callback", "a00078.html#a92bdef06bc6ff00af2de809bf0a91210", null ],
    [ "token", "a00078.html#a4add53cf81e94b21c2570eaaa87b06ca", null ],
    [ "token_len", "a00078.html#aa45f0f903c6fae2f2cf3662325cb11ec", null ]
];