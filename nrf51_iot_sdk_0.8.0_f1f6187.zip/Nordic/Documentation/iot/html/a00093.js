var a00093 =
[
    [ "flags", "a00093.html#a21f14e81bb3c47a3839b265faef99d6b", null ],
    [ "length", "a00093.html#a00fba2fed2987a9ed602fb22a28310ff", null ],
    [ "type", "a00093.html#a2ce9917382d0c86776ee83cee5745505", null ]
];