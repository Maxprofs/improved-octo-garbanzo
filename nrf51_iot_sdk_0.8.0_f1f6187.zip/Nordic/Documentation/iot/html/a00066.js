var a00066 =
[
    [ "Using the Californium (Cf) CoAP Framework", "a00054.html", [
      [ "Prerequisites", "a00054.html#iot_sdk_user_guides_java_coaps_prereq", null ],
      [ "Preparing the workspace", "a00054.html#iot_sdk_user_guides_java_coaps_workspace", [
        [ "Add supplied files to the local repositories", "a00054.html#iot_sdk_user_guides_java_coaps_workspace_copy", null ],
        [ "Import projects", "a00054.html#iot_sdk_user_guides_java_coaps_workspace_import", null ],
        [ "Change settings", "a00054.html#iot_sdk_user_guides_java_coaps_workspace_edit", null ]
      ] ],
      [ "Running a secure CoAP server", "a00054.html#iot_sdk_user_guides_java_coaps_server", null ],
      [ "Running a secure CoAP client", "a00054.html#iot_sdk_user_guides_java_coaps_client", null ]
    ] ]
];