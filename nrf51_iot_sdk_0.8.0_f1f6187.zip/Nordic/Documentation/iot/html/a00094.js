var a00094 =
[
    [ "length", "a00094.html#a9819ae5969c53e86e67c8ab023f29b8c", null ],
    [ "p_memory", "a00094.html#a83af9f09279251888d72d4e8a9685931", null ],
    [ "p_payload", "a00094.html#af72d5cf4c52c8dadaa7982f3250e2489", null ],
    [ "type", "a00094.html#a71e6128be5efbcf0ab43faf5d34f9052", null ]
];