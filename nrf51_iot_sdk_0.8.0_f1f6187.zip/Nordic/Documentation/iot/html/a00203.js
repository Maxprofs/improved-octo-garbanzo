var a00203 =
[
    [ "iot_context_id_t", "a00090.html", [
      [ "dest_cntxt_id", "a00090.html#ad441bc269c7994f31a2ee8bd9a2e2a4e", null ],
      [ "src_cntxt_id", "a00090.html#af2120e3fd9f7511df85135c7801f4a15", null ]
    ] ],
    [ "iot_context_t", "a00091.html", [
      [ "compression_flag", "a00091.html#ac698c1a4e92b32c76aeb32d294597239", null ],
      [ "context_id", "a00091.html#ab4b9f418db1963afdcb7dd5895ddbb4b", null ],
      [ "prefix", "a00091.html#a6b2efab0f3511964ab3b21dafcb758aa", null ],
      [ "prefix_len", "a00091.html#a442a4472d16b021426d9bb80abad05ee", null ]
    ] ],
    [ "iot_interface_t", "a00092.html", [
      [ "local_addr", "a00092.html#ad4d22338c04caf82588935f7726e1dbd", null ],
      [ "p_transport", "a00092.html#a53e1924970d1c2b8b4ef9b949ed19b71", null ],
      [ "p_upper_stack", "a00092.html#ab16e280cedc2a19d9804f3e04a5b4af4", null ],
      [ "peer_addr", "a00092.html#a569889865dfd7b30b5d6ca9513cbd0c9", null ],
      [ "tx_contexts", "a00092.html#ab6b2ad6325098db2bf3f3fd90aab0229", null ]
    ] ]
];