var a00024 =
[
    [ "Server", "a00034.html", [
      [ "Common module dependency and usage", "a00034.html#iot_sdk_app_coap_server_module_usage", null ],
      [ "Setup", "a00034.html#iot_sdk_app_coap_server_setup", null ],
      [ "Testing", "a00034.html#iot_sdk_app_coap_server_test", null ],
      [ "Python Client Example", "a00034.html#iot_sdk_app_coap_server_python_sample", null ],
      [ "Troubleshooting Guide", "a00034.html#iot_sdk_app_coap_server_tbg", null ]
    ] ],
    [ "Observable Server", "a00035.html", [
      [ "Common module dependency and usage", "a00035.html#iot_sdk_app_coap_server_obs_module_usage", null ],
      [ "Setup", "a00035.html#iot_sdk_app_coap_server_obs_setup", null ],
      [ "Testing", "a00035.html#iot_sdk_app_coap_server_obs_test", null ],
      [ "Python Client Example", "a00035.html#iot_sdk_app_coap_server_observe_python_sample", null ],
      [ "Troubleshooting Guide", "a00035.html#iot_sdk_app_coap_server_obs_tbg", null ]
    ] ],
    [ "Client", "a00032.html", [
      [ "Common module dependency and usage", "a00032.html#iot_sdk_app_coap_client_module_usage", null ],
      [ "Setup", "a00032.html#iot_sdk_app_coap_client_setup", null ],
      [ "Testing", "a00032.html#iot_sdk_app_coap_client_test", null ],
      [ "Python Server Example", "a00032.html#iot_sdk_app_server_python_sample", null ],
      [ "Troubleshooting Guide", "a00032.html#iot_sdk_app_coap_client_tbg", null ]
    ] ],
    [ "Observer Client", "a00033.html", [
      [ "Common module dependency and usage", "a00033.html#iot_sdk_app_coap_client_obs_module_usage", null ],
      [ "Setup", "a00033.html#iot_sdk_app_coap_client_obs_setup", null ],
      [ "Test", "a00033.html#iot_sdk_app_coap_client_obs_test", null ],
      [ "Python Server Example", "a00033.html#iot_sdk_app_coap_client_obs_python_sample", null ],
      [ "Troubleshooting Guide", "a00033.html#iot_sdk_app_coap_client_obs_tbg", null ]
    ] ]
];