var a00104 =
[
    [ "callback_data", "a00104.html#a65a64e082cae7f19a28696c03a08ba39", null ],
    [ "time_from_server", "a00104.html#a0abea2e283e46e81204d2bd6b78f69e0", null ]
];