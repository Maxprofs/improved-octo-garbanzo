var a00023 =
[
    [ "CoAP", "a00017.html", "a00017" ],
    [ "MQTT", "a00020.html", "a00020" ]
];