var a00082 =
[
    [ "addr", "a00082.html#a48933525c4846624c19e8965fa002375", null ],
    [ "port_number", "a00082.html#abb615d3999359f9af2fdec3d4b5c6de2", null ]
];