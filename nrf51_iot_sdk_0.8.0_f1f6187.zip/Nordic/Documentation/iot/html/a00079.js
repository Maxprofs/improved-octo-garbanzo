var a00079 =
[
    [ "ct", "a00079.html#a37df9789d39dad020e7f97ed44406079", null ],
    [ "p_resource_of_interest", "a00079.html#a8f8587444500a9cab277f8a0ac486810", null ],
    [ "remote", "a00079.html#a5a13129e411c8e332ce7a8ba12531f85", null ],
    [ "token", "a00079.html#aa8274498ddcad97903a9bfc4d6c690b6", null ],
    [ "token_len", "a00079.html#adae069e4db25def2328f0c0b5a95e56d", null ]
];