var group__MESH__SERIAL__HANDLER__OPENMESH =
[
    [ "serial_handler_openmesh_rx", "group__MESH__SERIAL__HANDLER__OPENMESH.html#ga366395caf43001539b1c815a62f8fd30", null ]
];