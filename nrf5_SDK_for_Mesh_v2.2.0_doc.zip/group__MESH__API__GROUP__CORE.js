var group__MESH__API__GROUP__CORE =
[
    [ "Core Mesh API", "group__NRF__MESH.html", "group__NRF__MESH" ],
    [ "Core configuration", "group__CORE__CONFIG.html", "group__CORE__CONFIG" ]
];