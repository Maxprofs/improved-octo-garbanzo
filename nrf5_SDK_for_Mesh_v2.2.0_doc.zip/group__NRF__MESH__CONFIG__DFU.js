var group__NRF__MESH__CONFIG__DFU =
[
    [ "NRF_MESH_DFU_TX_SLOTS", "group__NRF__MESH__CONFIG__DFU.html#gab2fdfbcce0b22fe2bc7c5df6ba296264", null ],
    [ "NRF_MESH_DFU_REQ_TIMEOUT_US", "group__NRF__MESH__CONFIG__DFU.html#gaed8e2d48cdb51dd415d254587fe78a1a", null ]
];