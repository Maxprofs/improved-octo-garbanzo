var group__NRF__MESH__CONFIG__BEARER =
[
    [ "General configuration", "group__MESH__CONFIG__BEARER.html", "group__MESH__CONFIG__BEARER" ],
    [ "Bearer event configuration", "group__MESH__CONFIG__BEARER__EVENT.html", "group__MESH__CONFIG__BEARER__EVENT" ]
];