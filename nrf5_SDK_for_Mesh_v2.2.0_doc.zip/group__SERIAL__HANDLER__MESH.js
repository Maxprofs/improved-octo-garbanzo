var group__SERIAL__HANDLER__MESH =
[
    [ "serial_handler_mesh_init", "group__SERIAL__HANDLER__MESH.html#ga6245263bf15bade8a7c1b8c39a5ae68b", null ],
    [ "serial_handler_mesh_rx", "group__SERIAL__HANDLER__MESH.html#ga09e4ecd45de33db87d6c83127cd9be44", null ]
];