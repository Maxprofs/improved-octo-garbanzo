var group__MESH__CONFIG__LISTENER__MODULE =
[
    [ "mesh_config_listener_t", "structmesh__config__listener__t.html", [
      [ "p_id", "structmesh__config__listener__t.html#a8e6bfbd669948b8b371976ea0b5c2a23", null ],
      [ "callback", "structmesh__config__listener__t.html#ab06541f2227e3d0fcbe1f76d70507518", null ]
    ] ],
    [ "MESH_CONFIG_LISTENER", "group__MESH__CONFIG__LISTENER__MODULE.html#ga0d362d004a75585478cb287b4f7d3bd2", null ],
    [ "mesh_config_listener_on_change_t", "group__MESH__CONFIG__LISTENER__MODULE.html#gad06ac3f915653d7a375623ebaa2da205", null ],
    [ "mesh_config_change_reason_t", "group__MESH__CONFIG__LISTENER__MODULE.html#ga8c8225ca694955074514a4a770dbdb35", [
      [ "MESH_CONFIG_CHANGE_REASON_SET", "group__MESH__CONFIG__LISTENER__MODULE.html#gga8c8225ca694955074514a4a770dbdb35af08dd808c4f9a23b3eedf8bf10267d93", null ],
      [ "MESH_CONFIG_CHANGE_REASON_DELETE", "group__MESH__CONFIG__LISTENER__MODULE.html#gga8c8225ca694955074514a4a770dbdb35a9182929db999af5c7597be097066970b", null ]
    ] ]
];