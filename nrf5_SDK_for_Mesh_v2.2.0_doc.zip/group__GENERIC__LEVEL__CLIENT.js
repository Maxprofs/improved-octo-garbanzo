var group__GENERIC__LEVEL__CLIENT =
[
    [ "generic_level_client_callbacks_t", "structgeneric__level__client__callbacks__t.html", [
      [ "level_status_cb", "structgeneric__level__client__callbacks__t.html#a7ef64fdea1753824ceccaf17d9eabb86", null ],
      [ "ack_transaction_status_cb", "structgeneric__level__client__callbacks__t.html#af4d38568d8666aa1f8d73afb39540a5e", null ],
      [ "periodic_publish_cb", "structgeneric__level__client__callbacks__t.html#a44a9ee43486a7760b4ed65f63d3ec654", null ]
    ] ],
    [ "generic_level_client_settings_t", "structgeneric__level__client__settings__t.html", [
      [ "timeout", "structgeneric__level__client__settings__t.html#afc8358bf1906840b570ecf60dc5097a2", null ],
      [ "force_segmented", "structgeneric__level__client__settings__t.html#a6bd733dcaa92de7e60cdb8082d538d0e", null ],
      [ "transmic_size", "structgeneric__level__client__settings__t.html#a86d163154db3fe0b2c0e980976259f1a", null ],
      [ "p_callbacks", "structgeneric__level__client__settings__t.html#a670ec9f0faba2cc24d828e1e2e367688", null ]
    ] ],
    [ "generic_level_client_msg_data_t", "uniongeneric__level__client__msg__data__t.html", [
      [ "set", "uniongeneric__level__client__msg__data__t.html#acd157bbda1cb4c696f313d2d920fd51f", null ],
      [ "delta_set", "uniongeneric__level__client__msg__data__t.html#a081f174e4246914ffd1c0d3839a889c7", null ],
      [ "move_set", "uniongeneric__level__client__msg__data__t.html#a58f67ef8fbb245f8eb7ea7a7e0d75f6b", null ]
    ] ],
    [ "generic_level_client_t", "struct____generic__level__client__t.html", [
      [ "model_handle", "struct____generic__level__client__t.html#a5ffd939cfd48e4d8c80f0a57774aac9d", null ],
      [ "msg_pkt", "struct____generic__level__client__t.html#adb811e2b628de483530885d6a0580a8c", null ],
      [ "access_message", "struct____generic__level__client__t.html#abb4c3b252d053eb69d3efa107e19bafa", null ],
      [ "settings", "struct____generic__level__client__t.html#a43871d488b24ec2465d14dba9b01950d", null ]
    ] ],
    [ "GENERIC_LEVEL_CLIENT_MODEL_ID", "group__GENERIC__LEVEL__CLIENT.html#gad0934e20432594ddb72ace4f63be5d11", null ],
    [ "generic_level_state_status_cb_t", "group__GENERIC__LEVEL__CLIENT.html#ga9b9a93096a09cc879fc6225c85dabd5f", null ],
    [ "generic_level_client_init", "group__GENERIC__LEVEL__CLIENT.html#ga5b8a5500f9bca4178e89427e7d001b85", null ],
    [ "generic_level_client_set", "group__GENERIC__LEVEL__CLIENT.html#gacc82af7d8a1a0b0d1c0db3a082415634", null ],
    [ "generic_level_client_set_unack", "group__GENERIC__LEVEL__CLIENT.html#gad6e397f5f14fed291dfeb797387f93bb", null ],
    [ "generic_level_client_delta_set", "group__GENERIC__LEVEL__CLIENT.html#ga68a6ceed67725ded3ad2eb8416365829", null ],
    [ "generic_level_client_delta_set_unack", "group__GENERIC__LEVEL__CLIENT.html#ga5d3a8a16faa08c9d0cd6f08d9c22137a", null ],
    [ "generic_level_client_move_set", "group__GENERIC__LEVEL__CLIENT.html#gaa39c32a8760f7b09f3a0ffd0cc296494", null ],
    [ "generic_level_client_move_set_unack", "group__GENERIC__LEVEL__CLIENT.html#ga7479fb274c23522ea78d4a49e9677443", null ],
    [ "generic_level_client_get", "group__GENERIC__LEVEL__CLIENT.html#ga6c43481a8b3fcc3466494a5270522e07", null ]
];