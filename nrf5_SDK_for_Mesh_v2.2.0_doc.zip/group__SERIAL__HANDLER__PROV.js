var group__SERIAL__HANDLER__PROV =
[
    [ "serial_handler_prov_init", "group__SERIAL__HANDLER__PROV.html#ga27d9ad0d166db07bcd740c97fb61dc21", null ],
    [ "serial_handler_prov_pkt_in", "group__SERIAL__HANDLER__PROV.html#gaeffff35d4961a9ae4c94f583fce662a4", null ],
    [ "serial_handler_prov_context_get", "group__SERIAL__HANDLER__PROV.html#gaf8bd21a532ba61f7d70edb28a177f160", null ],
    [ "serial_handler_prov_keys_get", "group__SERIAL__HANDLER__PROV.html#gabdd30fcdfec9e407fab2902247ca4283", null ],
    [ "serial_handler_prov_oob_caps_get", "group__SERIAL__HANDLER__PROV.html#gaeccb5d9b751f41cc592d3d233ec6f140", null ]
];