var group__MESH__SERIAL__HANDLER__APP =
[
    [ "serial_handler_app_cb_set", "group__MESH__SERIAL__HANDLER__APP.html#gabd5af00c39b4f5b334cf94255f07efe3", null ],
    [ "serial_handler_app_rx", "group__MESH__SERIAL__HANDLER__APP.html#ga3fc6413c596bc06662fc8bad4a7d6b3b", null ]
];