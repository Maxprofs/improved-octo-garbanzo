var group__GENERIC__DTT__MODEL =
[
    [ "Generic Default Transition Time client model interface", "group__GENERIC__DTT__CLIENT.html", "group__GENERIC__DTT__CLIENT" ],
    [ "Generic Default Transition Time server model interface", "group__GENERIC__DTT__SERVER.html", "group__GENERIC__DTT__SERVER" ],
    [ "generic_dtt_set_params_t", "structgeneric__dtt__set__params__t.html", [
      [ "transition_time_ms", "structgeneric__dtt__set__params__t.html#a8209286ec7b8954e5e99bcefc3ae8852", null ]
    ] ],
    [ "generic_dtt_status_params_t", "structgeneric__dtt__status__params__t.html", [
      [ "transition_time_ms", "structgeneric__dtt__status__params__t.html#a9ceb9add3b52eef6b848918e5e2d6259", null ]
    ] ],
    [ "GENERIC_DTT_COMPANY_ID", "group__GENERIC__DTT__MODEL.html#gab0b966ac1399bb424f4a54e33d484e1c", null ]
];