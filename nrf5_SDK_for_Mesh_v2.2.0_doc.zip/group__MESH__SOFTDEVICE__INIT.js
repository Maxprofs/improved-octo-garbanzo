var group__MESH__SOFTDEVICE__INIT =
[
    [ "mesh_softdevice_init", "group__MESH__SOFTDEVICE__INIT.html#ga5d72d22a81e3da81f65901da14605d78", null ]
];