var group__MESH__OPT__CORE =
[
    [ "mesh_opt_core_adv_t", "structmesh__opt__core__adv__t.html", [
      [ "enabled", "structmesh__opt__core__adv__t.html#abfd7f5ce68bff687aeae3cfc09b2dc90", null ],
      [ "tx_count", "structmesh__opt__core__adv__t.html#a762fd9d9c5061fdd40a33403af8dd5e4", null ],
      [ "tx_interval_ms", "structmesh__opt__core__adv__t.html#a1e3ec732d72fbe2591a227bf8d1c595e", null ]
    ] ],
    [ "MESH_OPT_CORE_ADV_EID", "group__MESH__OPT__CORE.html#ga7c8652a91fb47ae9da02dfed9faea078", null ],
    [ "MESH_OPT_CORE_TX_POWER_EID", "group__MESH__OPT__CORE.html#ga43446c287185c02a6d8e2896721e7f60", null ],
    [ "MESH_OPT_CORE_ADV_ADDR_EID", "group__MESH__OPT__CORE.html#gadff9612bb8b9ea4629fd4fee2af5c567", null ],
    [ "MESH_OPT_CORE_SEC_NWK_BCN_EID", "group__MESH__OPT__CORE.html#ga29df7ab4ce76a8e6cf20fd90b014412d", null ],
    [ "MESH_OPT_CORE_HB_PUBLICATION_EID", "group__MESH__OPT__CORE.html#ga75680a5fd7888cf5dc7f407d6ff04ea1", null ],
    [ "mesh_opt_core_adv_set", "group__MESH__OPT__CORE.html#gaa364833c141d46ba4791e7f134be31fd", null ],
    [ "mesh_opt_core_adv_get", "group__MESH__OPT__CORE.html#gab21546ab3cf90398b667114ed8e4d243", null ],
    [ "mesh_opt_core_tx_power_set", "group__MESH__OPT__CORE.html#ga3ed961289f0246c32d3ee89f06eebd1a", null ],
    [ "mesh_opt_core_tx_power_get", "group__MESH__OPT__CORE.html#ga62808df6b04c638ca2dc56b501dbe3ff", null ],
    [ "mesh_opt_core_adv_addr_set", "group__MESH__OPT__CORE.html#ga69a4b612e5989f682c90f8c2a5098626", null ],
    [ "mesh_opt_core_adv_addr_get", "group__MESH__OPT__CORE.html#gaf3c1fccfe81ca75de7d5b4ae712b36e6", null ]
];