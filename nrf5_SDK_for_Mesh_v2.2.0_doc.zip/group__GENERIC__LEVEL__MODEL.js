var group__GENERIC__LEVEL__MODEL =
[
    [ "Generic Level client model interface", "group__GENERIC__LEVEL__CLIENT.html", "group__GENERIC__LEVEL__CLIENT" ],
    [ "Generic Level server model interface", "group__GENERIC__LEVEL__SERVER.html", "group__GENERIC__LEVEL__SERVER" ],
    [ "generic_level_set_params_t", "structgeneric__level__set__params__t.html", [
      [ "level", "structgeneric__level__set__params__t.html#a131edb3d6fcdc37a231771c5968647a7", null ],
      [ "tid", "structgeneric__level__set__params__t.html#ac94c45132dbfd618e88e90c9376d03a5", null ]
    ] ],
    [ "generic_level_delta_set_params_t", "structgeneric__level__delta__set__params__t.html", [
      [ "delta_level", "structgeneric__level__delta__set__params__t.html#ac0ed28e2d9d75ae9e2f788c9e0b8f247", null ],
      [ "tid", "structgeneric__level__delta__set__params__t.html#a47506c231ce3fa998cb91e361963502b", null ]
    ] ],
    [ "generic_level_move_set_params_t", "structgeneric__level__move__set__params__t.html", [
      [ "move_level", "structgeneric__level__move__set__params__t.html#a9dedc405c84ada401068b9d315766f91", null ],
      [ "tid", "structgeneric__level__move__set__params__t.html#a1340519b687d6c4a2ca025a4aed387db", null ]
    ] ],
    [ "generic_level_status_params_t", "structgeneric__level__status__params__t.html", [
      [ "present_level", "structgeneric__level__status__params__t.html#ab84806d6b5a44177e9de0482639518d6", null ],
      [ "target_level", "structgeneric__level__status__params__t.html#a4cc3ad7cfb43eb1c540e00a86885cbdd", null ],
      [ "remaining_time_ms", "structgeneric__level__status__params__t.html#a92bd7179cb51116c86127b085478d683", null ]
    ] ],
    [ "GENERIC_LEVEL_COMPANY_ID", "group__GENERIC__LEVEL__MODEL.html#ga20c6b1582a7d09a2a9051ea0aa0fedf2", null ]
];