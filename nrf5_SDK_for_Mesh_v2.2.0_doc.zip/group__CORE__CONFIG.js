var group__CORE__CONFIG =
[
    [ "Compile time configuration", "group__NRF__MESH__CONFIG__CORE.html", "group__NRF__MESH__CONFIG__CORE" ],
    [ "Runtime configuration", "group__NRF__MESH__CONFIGURE.html", "group__NRF__MESH__CONFIGURE" ]
];