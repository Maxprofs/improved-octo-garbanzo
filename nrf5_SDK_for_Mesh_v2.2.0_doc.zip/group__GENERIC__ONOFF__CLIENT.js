var group__GENERIC__ONOFF__CLIENT =
[
    [ "generic_onoff_client_callbacks_t", "structgeneric__onoff__client__callbacks__t.html", [
      [ "onoff_status_cb", "structgeneric__onoff__client__callbacks__t.html#aaf548728fd93c86e3cb0a55e6ef06150", null ],
      [ "ack_transaction_status_cb", "structgeneric__onoff__client__callbacks__t.html#ac0a18342ef7036d1b6c54a4770a27abd", null ],
      [ "periodic_publish_cb", "structgeneric__onoff__client__callbacks__t.html#ae8ddb49239e9bb7ea9c575b54a6cb1b5", null ]
    ] ],
    [ "generic_onoff_client_settings_t", "structgeneric__onoff__client__settings__t.html", [
      [ "timeout", "structgeneric__onoff__client__settings__t.html#aa0920aa72e01858719fe09e3a348656d", null ],
      [ "force_segmented", "structgeneric__onoff__client__settings__t.html#a13bc04dcd84a565e3d90a7090904fe79", null ],
      [ "transmic_size", "structgeneric__onoff__client__settings__t.html#abe3a918c7daa2d3b00ef9c45f15517c2", null ],
      [ "p_callbacks", "structgeneric__onoff__client__settings__t.html#a1b940ec682a27ba96a0293b7ef15b83d", null ]
    ] ],
    [ "generic_onoff_client_msg_data_t", "uniongeneric__onoff__client__msg__data__t.html", [
      [ "set", "uniongeneric__onoff__client__msg__data__t.html#a23fb901f8604ed6ac2e61f48386f2c52", null ]
    ] ],
    [ "generic_onoff_client_t", "struct____generic__onoff__client__t.html", [
      [ "model_handle", "struct____generic__onoff__client__t.html#ac71f2586e6ce2a07607c237f6c34aa19", null ],
      [ "msg_pkt", "struct____generic__onoff__client__t.html#a80e65a7a3c46bbb40d122cf95f34907c", null ],
      [ "access_message", "struct____generic__onoff__client__t.html#a15f987e34a06ab8a79a429ba6c9c87ef", null ],
      [ "settings", "struct____generic__onoff__client__t.html#a5cf3ee0156a8078e6c1d91af7a533de7", null ]
    ] ],
    [ "GENERIC_ONOFF_CLIENT_MODEL_ID", "group__GENERIC__ONOFF__CLIENT.html#ga572847c98b957eee1a4bc7bb64e50362", null ],
    [ "generic_onoff_state_status_cb_t", "group__GENERIC__ONOFF__CLIENT.html#gab5d83bbce066d7fb95f68ea9a6d330a5", null ],
    [ "generic_onoff_client_init", "group__GENERIC__ONOFF__CLIENT.html#ga755ac4f33906a7310f647e33b0c92470", null ],
    [ "generic_onoff_client_set", "group__GENERIC__ONOFF__CLIENT.html#ga20fa27358a537b824c47615c358b3e6f", null ],
    [ "generic_onoff_client_set_unack", "group__GENERIC__ONOFF__CLIENT.html#ga09f2115b0c4b0ca14264c8cc5b0734fe", null ],
    [ "generic_onoff_client_get", "group__GENERIC__ONOFF__CLIENT.html#gad9ab49440c6b1860da7fc5896090b6f0", null ]
];