var group__NRF__MESH__CONFIGURE =
[
    [ "nrf_mesh_configure_device_uuid_set", "group__NRF__MESH__CONFIGURE.html#ga2322fa6389cb004cd867dce8e66b8e3f", null ],
    [ "nrf_mesh_configure_device_uuid_reset", "group__NRF__MESH__CONFIGURE.html#ga28a63fc13fd70283c61aff3cdbc2a0df", null ],
    [ "nrf_mesh_configure_device_uuid_get", "group__NRF__MESH__CONFIGURE.html#gaacce7216f13e860a91ff96af480f104e", null ]
];