var group__NRF__MESH__CONFIG__SERIAL =
[
    [ "UART Hardware configuration", "group__NRF__MESH__CONFIG__SERIAL__UART.html", "group__NRF__MESH__CONFIG__SERIAL__UART" ],
    [ "NRF_MESH_SERIAL_BEACON_SLOTS", "group__NRF__MESH__CONFIG__SERIAL.html#ga20189cc203055596d3c5fcbf6a8a209c", null ]
];