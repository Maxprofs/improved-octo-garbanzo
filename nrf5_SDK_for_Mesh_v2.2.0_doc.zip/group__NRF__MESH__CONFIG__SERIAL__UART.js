var group__NRF__MESH__CONFIG__SERIAL__UART =
[
    [ "HWFC", "group__NRF__MESH__CONFIG__SERIAL__UART.html#ga51e7b9a81c7a8cf41c6b26e1ff1b547a", null ],
    [ "SERIAL_UART_BAUDRATE", "group__NRF__MESH__CONFIG__SERIAL__UART.html#ga82fdf5c1f2a90c63cde21703e623749d", null ]
];