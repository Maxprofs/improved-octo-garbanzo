var group__MESH__API__GROUP__GENERIC__MODELS =
[
    [ "Generic Default Transition Time model", "group__GENERIC__DTT__MODEL.html", "group__GENERIC__DTT__MODEL" ],
    [ "Generic OnOff model", "group__GENERIC__ONOFF__MODEL.html", "group__GENERIC__ONOFF__MODEL" ],
    [ "Generic Level model", "group__GENERIC__LEVEL__MODEL.html", "group__GENERIC__LEVEL__MODEL" ]
];