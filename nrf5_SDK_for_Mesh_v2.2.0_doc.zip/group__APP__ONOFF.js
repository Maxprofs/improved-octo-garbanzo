var group__APP__ONOFF =
[
    [ "app_onoff_state_t", "structapp__onoff__state__t.html", [
      [ "present_onoff", "structapp__onoff__state__t.html#a43112b03c7f7bca87629e641f115cf08", null ],
      [ "target_onoff", "structapp__onoff__state__t.html#a07d23933bb1018ceb944f6766fc62fce", null ],
      [ "remaining_time_ms", "structapp__onoff__state__t.html#a5b61fa537a901e1b3dcd0982bce57600", null ],
      [ "delay_ms", "structapp__onoff__state__t.html#abba1ebd843db00d2e9606a8b79229c88", null ]
    ] ],
    [ "app_onoff_server_t", "struct____app__onoff__server__t.html", [
      [ "server", "struct____app__onoff__server__t.html#abb3935831d96536dcbecfee59fae9e78", null ],
      [ "p_timer_id", "struct____app__onoff__server__t.html#a85bc0ef775be25d19f1d55e59173133b", null ],
      [ "onoff_set_cb", "struct____app__onoff__server__t.html#aa1bfe59cfb55eb783571f78cf086affb", null ],
      [ "onoff_get_cb", "struct____app__onoff__server__t.html#a819cf4cb0be4b8b0e832b87ed9eeb798", null ],
      [ "state", "struct____app__onoff__server__t.html#aa6019526fdbb7507dd1e272e3b824f10", null ],
      [ "last_rtc_counter", "struct____app__onoff__server__t.html#a13a586a1a91d505320a7d7019fe06e5f", null ],
      [ "value_updated", "struct____app__onoff__server__t.html#aa6bd52ac57a302a58ef366a7593ee830", null ]
    ] ],
    [ "APP_ONOFF_SERVER_DEF", "group__APP__ONOFF.html#ga5fa554333d0a9948a6c00ef603adde4c", null ],
    [ "app_onoff_set_cb_t", "group__APP__ONOFF.html#ga6e3bf494ee40200a788c6fbf2a4c389e", null ],
    [ "app_onoff_get_cb_t", "group__APP__ONOFF.html#gabbddf882d493baf90e49f34732259622", null ],
    [ "app_onoff_status_publish", "group__APP__ONOFF.html#ga6b3bc0a732211c5a52e446d375d0fdff", null ],
    [ "app_onoff_init", "group__APP__ONOFF.html#ga2e45a52793f3e475d11c4f0e2268c60b", null ]
];