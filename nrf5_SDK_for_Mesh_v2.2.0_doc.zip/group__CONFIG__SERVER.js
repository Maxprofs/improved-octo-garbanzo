var group__CONFIG__SERVER =
[
    [ "Configuration Server application events", "group__CONFIG__SERVER__EVENTS.html", "group__CONFIG__SERVER__EVENTS" ],
    [ "config_server_init", "group__CONFIG__SERVER.html#ga8803043b6bf93299f7fb756be490855d", null ],
    [ "config_server_bind", "group__CONFIG__SERVER.html#ga8e0929bb95cd98c68dab741a7f464a76", null ]
];