var group__GENERIC__ONOFF__SERVER =
[
    [ "generic_onoff_server_state_cbs_t", "structgeneric__onoff__server__state__cbs__t.html", [
      [ "set_cb", "structgeneric__onoff__server__state__cbs__t.html#a321af292eb4bf0fa50f36b9cc41f119d", null ],
      [ "get_cb", "structgeneric__onoff__server__state__cbs__t.html#a00ef43b60ac9ef27717c34fd0877d96a", null ]
    ] ],
    [ "generic_onoff_server_callbacks_t", "structgeneric__onoff__server__callbacks__t.html", [
      [ "onoff_cbs", "structgeneric__onoff__server__callbacks__t.html#a9830d0e808753c1e8b383af7dba5e1ba", null ]
    ] ],
    [ "generic_onoff_server_settings_t", "structgeneric__onoff__server__settings__t.html", [
      [ "force_segmented", "structgeneric__onoff__server__settings__t.html#a0177ca29d5ac11bfbf2bb93dabfe2483", null ],
      [ "transmic_size", "structgeneric__onoff__server__settings__t.html#a0fb92cf8c43d8e056490593951019a83", null ],
      [ "p_callbacks", "structgeneric__onoff__server__settings__t.html#a3ed33da9e767dc7bf1bfec9014e361af", null ]
    ] ],
    [ "generic_onoff_server_t", "struct____generic__onoff__server__t.html", [
      [ "model_handle", "struct____generic__onoff__server__t.html#ada5a410382a986dc8a25cf3cc30b6ce1", null ],
      [ "tid_tracker", "struct____generic__onoff__server__t.html#a7140f84d9657c22991b1a25455aa1b56", null ],
      [ "settings", "struct____generic__onoff__server__t.html#ae96921c16da50499474565f3be738a37", null ]
    ] ],
    [ "GENERIC_ONOFF_SERVER_MODEL_ID", "group__GENERIC__ONOFF__SERVER.html#gaa2e776ba313752edb8507e8cefd21887", null ],
    [ "generic_onoff_state_set_cb_t", "group__GENERIC__ONOFF__SERVER.html#gae50ca0b3753f9595b82954fb73a7c2d6", null ],
    [ "generic_onoff_state_get_cb_t", "group__GENERIC__ONOFF__SERVER.html#gafbee0831f812067af77d5a7ef971616d", null ],
    [ "generic_onoff_server_init", "group__GENERIC__ONOFF__SERVER.html#ga9f4767d5e00f5f22251682698d9619b0", null ],
    [ "generic_onoff_server_status_publish", "group__GENERIC__ONOFF__SERVER.html#gab4c37afbe34fe728bacbdb752d32a076", null ]
];