var group__DSM__CONFIG =
[
    [ "DSM_SUBNET_MAX", "group__DSM__CONFIG.html#ga9537d9e92748008ba35d9afbd87461bb", null ],
    [ "DSM_APP_MAX", "group__DSM__CONFIG.html#ga48c3e6a2209b1455ea4d385a7a75ea03", null ],
    [ "DSM_DEVICE_MAX", "group__DSM__CONFIG.html#ga92bb96de83a711552d1e27af6896dd77", null ],
    [ "DSM_VIRTUAL_ADDR_MAX", "group__DSM__CONFIG.html#ga3c7c07f86897299ae562bb052726ad20", null ],
    [ "DSM_NONVIRTUAL_ADDR_MAX", "group__DSM__CONFIG.html#ga45497ced9030c26188585ed9d88a7ce3", null ],
    [ "DSM_FLASH_PAGE_COUNT", "group__DSM__CONFIG.html#gad18f659d10f2fca20c05c165bd650dca", null ]
];