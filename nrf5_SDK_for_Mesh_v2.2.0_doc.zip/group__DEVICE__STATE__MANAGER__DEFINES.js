var group__DEVICE__STATE__MANAGER__DEFINES =
[
    [ "DSM_ADDR_MAX", "group__DEVICE__STATE__MANAGER__DEFINES.html#ga14289ea1c767a99e2c819cddfd62c4d4", null ],
    [ "DSM_HANDLE_INVALID", "group__DEVICE__STATE__MANAGER__DEFINES.html#gae718b3fc70ca49b854a9cccec4692f69", null ],
    [ "DSM_KEY_INDEX_MAX", "group__DEVICE__STATE__MANAGER__DEFINES.html#ga6baf4c778d97b7fea1db6e0013139389", null ]
];