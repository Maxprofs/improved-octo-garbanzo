var group__MESH__API__GROUP__PROV =
[
    [ "Provisioning configuration", "group__NRF__MESH__CONFIG__PROV.html", "group__NRF__MESH__CONFIG__PROV" ],
    [ "Provisioning API", "group__NRF__MESH__PROV.html", "group__NRF__MESH__PROV" ]
];