var group__GENERIC__ONOFF__MODEL =
[
    [ "Generic OnOff client model interface", "group__GENERIC__ONOFF__CLIENT.html", "group__GENERIC__ONOFF__CLIENT" ],
    [ "Generic OnOff server model interface", "group__GENERIC__ONOFF__SERVER.html", "group__GENERIC__ONOFF__SERVER" ],
    [ "generic_onoff_state_t", "structgeneric__onoff__state__t.html", [
      [ "on_off", "structgeneric__onoff__state__t.html#ade7c6575969f03214ff55f65dfd6c19e", null ],
      [ "tid", "structgeneric__onoff__state__t.html#a714f2970150c51d846c3508e1032e797", null ]
    ] ],
    [ "generic_onoff_set_params_t", "structgeneric__onoff__set__params__t.html", [
      [ "on_off", "structgeneric__onoff__set__params__t.html#a3058a484fe0c08b0cadbfc5699bbafe3", null ],
      [ "tid", "structgeneric__onoff__set__params__t.html#afaa5fb8876787e78df90a84b72ab1125", null ]
    ] ],
    [ "generic_onoff_status_params_t", "structgeneric__onoff__status__params__t.html", [
      [ "present_on_off", "structgeneric__onoff__status__params__t.html#aa778161338e339ec2bf9749c5efffac6", null ],
      [ "target_on_off", "structgeneric__onoff__status__params__t.html#a29a25210bf99162349635401c70b4483", null ],
      [ "remaining_time_ms", "structgeneric__onoff__status__params__t.html#a18c47a259c0c98bef8a83d6f87e14851", null ]
    ] ],
    [ "GENERIC_ONOFF_COMPANY_ID", "group__GENERIC__ONOFF__MODEL.html#ga048cefcb23bd55e1ec646415a60234bc", null ],
    [ "GENERIC_ONOFF_MAX", "group__GENERIC__ONOFF__MODEL.html#ga7614a2038fa0ad4507da3c3411586212", null ]
];