var group__MESH__API__GROUP__DFU =
[
    [ "DFU configuration", "group__NRF__MESH__CONFIG__DFU.html", "group__NRF__MESH__CONFIG__DFU" ],
    [ "DFU API", "group__NRF__MESH__DFU.html", "group__NRF__MESH__DFU" ]
];