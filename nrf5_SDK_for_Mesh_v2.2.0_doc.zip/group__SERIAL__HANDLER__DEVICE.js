var group__SERIAL__HANDLER__DEVICE =
[
    [ "serial_handler_device_init", "group__SERIAL__HANDLER__DEVICE.html#gaeee66e9ca9b4a705b83492f3907277a2", null ],
    [ "serial_handler_device_rx", "group__SERIAL__HANDLER__DEVICE.html#ga8cf1511bd58f5f10d8e61f8788408479", null ],
    [ "serial_handler_device_alloc_fail_report", "group__SERIAL__HANDLER__DEVICE.html#gafafc894de916d110c5661d6ff2ba1c42", null ]
];