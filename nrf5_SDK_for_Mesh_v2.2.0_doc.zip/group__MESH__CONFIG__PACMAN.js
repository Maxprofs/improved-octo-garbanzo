var group__MESH__CONFIG__PACMAN =
[
    [ "PACKET_MGR_DEBUG_MODE", "group__MESH__CONFIG__PACMAN.html#gabf71f2eb0608cf3ac1b6ed1ceaf86070", null ],
    [ "PACKET_MGR_MEMORY_POOL_SIZE", "group__MESH__CONFIG__PACMAN.html#gafd8386bc34a222181cd55b69c7959143", null ],
    [ "PACKET_MGR_BLAME_MODE", "group__MESH__CONFIG__PACMAN.html#ga1a886e86525be7245bdeb011a6d5d453", null ]
];