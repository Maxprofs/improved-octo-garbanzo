var group__MESH__CONFIG__ENTRY =
[
    [ "mesh_config_entry_id_t", "structmesh__config__entry__id__t.html", [
      [ "file", "structmesh__config__entry__id__t.html#af7181777fa130a004450a929f015851a", null ],
      [ "record", "structmesh__config__entry__id__t.html#abfd6deabc329bf174fb274387312bd9e", null ]
    ] ],
    [ "mesh_config_file_params_t", "structmesh__config__file__params__t.html", [
      [ "id", "structmesh__config__file__params__t.html#a271197cd974d14c0759945a78740d0ad", null ],
      [ "strategy", "structmesh__config__file__params__t.html#abb1c69be4f08fdcc2d6aca06653c9fa5", null ],
      [ "p_backend_data", "structmesh__config__file__params__t.html#a2997d41845205c1847b41a718f2f78a7", null ]
    ] ],
    [ "mesh_config_entry_params_t", "structmesh__config__entry__params__t.html", [
      [ "p_id", "structmesh__config__entry__params__t.html#a2c1d60e22811652d2fe1bc7845c438fe", null ],
      [ "entry_size", "structmesh__config__entry__params__t.html#a4f8ac710f533dce4795dad6a8c61eae4", null ],
      [ "max_count", "structmesh__config__entry__params__t.html#abdd4ca0326d0017126a1760e9413a689", null ],
      [ "p_default", "structmesh__config__entry__params__t.html#af797d16a9d28e03cb98d0eaacaf41ec4", null ],
      [ "setter", "structmesh__config__entry__params__t.html#a99b923d47f2be45ef1dd490e7b418cba", null ],
      [ "getter", "structmesh__config__entry__params__t.html#a9e72b6a2777a995942ed9f5a05d4dac1", null ],
      [ "deleter", "structmesh__config__entry__params__t.html#a055157921804a1c231b04d8f702383d2", null ],
      [ "callbacks", "structmesh__config__entry__params__t.html#af834f04f4476c7938ae316131cba4296", null ],
      [ "p_state", "structmesh__config__entry__params__t.html#a75cd312b02433f6e8041cf33792ab396", null ]
    ] ],
    [ "MESH_CONFIG_ENTRY_ID", "group__MESH__CONFIG__ENTRY.html#gaa4076d45c5b983d252a2e675a29eb7ea", null ],
    [ "MESH_CONFIG_ENTRY_MAX_SIZE", "group__MESH__CONFIG__ENTRY.html#ga0c346ba3266d0c934f16ad96167d59fc", null ],
    [ "MESH_CONFIG_FILE", "group__MESH__CONFIG__ENTRY.html#gacb310f7e7d1ede1e50db3a9d25ba3e26", null ],
    [ "MESH_CONFIG_ENTRY", "group__MESH__CONFIG__ENTRY.html#ga2db4f77fc83189dced1ec2f1c0e8d8c4", null ],
    [ "MESH_CONFIG_ENTRY_IMPLEMENTATION", "group__MESH__CONFIG__ENTRY.html#gadee81dcd4023dbab03aa26786075d3f2", null ],
    [ "MESH_CONFIG_ENTRY_API_DEFINE", "group__MESH__CONFIG__ENTRY.html#gafb6e6e0ead64abf44c11483342cbe9db", null ],
    [ "MESH_CONFIG_ENTRY_ARRAY_WRAPPER_DECLARE", "group__MESH__CONFIG__ENTRY.html#gaad9a2e4a1e8248e1801782dc0a2094a4", null ],
    [ "mesh_config_entry_set_t", "group__MESH__CONFIG__ENTRY.html#ga1ddfff9042f80b8d0a91074276c9950d", null ],
    [ "mesh_config_entry_get_t", "group__MESH__CONFIG__ENTRY.html#ga32996a88ca9accb18d5bb86d9d3bc060", null ],
    [ "mesh_config_entry_delete_t", "group__MESH__CONFIG__ENTRY.html#ga4df6e6dd926a107d32c989ad8f9b7728", null ],
    [ "mesh_config_strategy_t", "group__MESH__CONFIG__ENTRY.html#ga8bb18d01daf64c136d34d2f9fbd6651f", [
      [ "MESH_CONFIG_STRATEGY_NON_PERSISTENT", "group__MESH__CONFIG__ENTRY.html#gga8bb18d01daf64c136d34d2f9fbd6651fa80baf39c7ffbfbe0ba4a02e8e88fefd9", null ],
      [ "MESH_CONFIG_STRATEGY_CONTINUOUS", "group__MESH__CONFIG__ENTRY.html#gga8bb18d01daf64c136d34d2f9fbd6651fa3dff8196e47956f7a63710cf99dd9462", null ],
      [ "MESH_CONFIG_STRATEGY_ON_POWER_DOWN", "group__MESH__CONFIG__ENTRY.html#gga8bb18d01daf64c136d34d2f9fbd6651fa315495a744965e7bab172983579e14ab", null ]
    ] ],
    [ "mesh_config_entry_flags_t", "group__MESH__CONFIG__ENTRY.html#ga750f6cd92f1c866e33b503c41e77ac99", [
      [ "MESH_CONFIG_ENTRY_FLAG_DIRTY", "group__MESH__CONFIG__ENTRY.html#gga750f6cd92f1c866e33b503c41e77ac99a367256a46bbcf828903b1d37a69f5f09", null ],
      [ "MESH_CONFIG_ENTRY_FLAG_ACTIVE", "group__MESH__CONFIG__ENTRY.html#gga750f6cd92f1c866e33b503c41e77ac99a7f8199ee56b990efe9a77f78f2aae9d8", null ],
      [ "MESH_CONFIG_ENTRY_FLAG_BUSY", "group__MESH__CONFIG__ENTRY.html#gga750f6cd92f1c866e33b503c41e77ac99a654ec63dce3cef3181ec405b5688a6e4", null ]
    ] ]
];