var group__MODEL__COMMON =
[
    [ "model_transition_t", "structmodel__transition__t.html", [
      [ "transition_time_ms", "structmodel__transition__t.html#a425cfdd6d511ed34895f29a3e9b2975f", null ],
      [ "delay_ms", "structmodel__transition__t.html#aa22663702bf63a7ee5b269fa54128724", null ]
    ] ],
    [ "tid_tracker_t", "structtid__tracker__t.html", [
      [ "src", "structtid__tracker__t.html#aea5ff79e8d64a4e3d76dcf15757a6751", null ],
      [ "dst", "structtid__tracker__t.html#a9748278b481f2f99c88d3990aa4659f8", null ],
      [ "message_id", "structtid__tracker__t.html#a4c658ff7cf965f77231f209ee052e666", null ],
      [ "old_tid", "structtid__tracker__t.html#add7d99168076cff1abfa8a4dec59a37b", null ],
      [ "new_transaction", "structtid__tracker__t.html#a34bc4dc42b2cbfae1f8850b10a3660f5", null ],
      [ "tid_expiry_timer", "structtid__tracker__t.html#a48c6ee96d7db09dd132a449ed33df7a0", null ]
    ] ],
    [ "model_timer_t", "structmodel__timer__t.html", [
      [ "mode", "structmodel__timer__t.html#a984c30b3945eefb41c9cf632d1ed18d4", null ],
      [ "timeout_rtc_ticks", "structmodel__timer__t.html#af61bd02425cb075e1ea8562299e7e12c", null ],
      [ "p_context", "structmodel__timer__t.html#a769f3a940595831f9d2e0961048e4659", null ],
      [ "cb", "structmodel__timer__t.html#ab3ba381cc88dbc9d95a90560b31bdab7", null ],
      [ "total_rtc_ticks", "structmodel__timer__t.html#a5d4382deba55704e32729d3459ad39f0", null ],
      [ "p_timer_id", "structmodel__timer__t.html#af6e1c2600920e5bf49b448f9b498aefb", null ],
      [ "remaining_ticks", "structmodel__timer__t.html#a10a1fefb18530920f1549ea3f3c0ab6a", null ],
      [ "last_rtc_stamp", "structmodel__timer__t.html#afa47b4798e7ce3f5756ebe9d737c0c33", null ],
      [ "cb_active", "structmodel__timer__t.html#a7be4ac4eb6818c7970da319fe9472c62", null ]
    ] ],
    [ "MODEL_TRANSITION_TIME_INVALID", "group__MODEL__COMMON.html#ga1e8a4dd600f3f99338228c917a60bc6e", null ],
    [ "MODEL_ACKNOWLEDGED_TRANSACTION_TIMEOUT", "group__MODEL__COMMON.html#ga0116884e2df4187ccd605f975a28f95e", null ],
    [ "TRANSITION_TIME_STEP_100MS_MAX", "group__MODEL__COMMON.html#ga43a12c4d7f63f9c097013160ad19c0d3", null ],
    [ "TRANSITION_TIME_STEP_1S_MAX", "group__MODEL__COMMON.html#ga83677fea0b12fe30a8676f801a019aaf", null ],
    [ "TRANSITION_TIME_STEP_10S_MAX", "group__MODEL__COMMON.html#ga9c21549b62bca3a652b326e92563549b", null ],
    [ "TRANSITION_TIME_STEP_10M_MAX", "group__MODEL__COMMON.html#gaabe7d1915c46615677823a896e220a4a", null ],
    [ "TRANSITION_TIME_MAX", "group__MODEL__COMMON.html#ga1228e38ac5e3828e55b71e3a5aea4339", null ],
    [ "TRANSITION_TIME_UNKNOWN", "group__MODEL__COMMON.html#ga6eae5c842fed0a1991de7ecb48b5f60e", null ],
    [ "TRANSITION_TIME_MAX_MS", "group__MODEL__COMMON.html#ga0d07bbeaf74ad1a84f1747801dbf93bf", null ],
    [ "DELAY_TIME_STEP_FACTOR_MS", "group__MODEL__COMMON.html#ga06e564bd3fbedd48e34a83360a1b361a", null ],
    [ "DELAY_TIME_STEP_MAX", "group__MODEL__COMMON.html#gad025813adfa5aa8a7bf422836501fbf3", null ],
    [ "DELAY_TIME_MAX_MS", "group__MODEL__COMMON.html#ga611539538f416196539051a83140bd05", null ],
    [ "MODEL_TIMER_TIMEOUT_MIN_TICKS", "group__MODEL__COMMON.html#ga6b00d347c1020791536e16fc1f878924", null ],
    [ "MODEL_TIMER_TIMEOUT_MIN_US", "group__MODEL__COMMON.html#ga448dee948fdd405cb703bd9babbb6a0c", null ],
    [ "MODEL_TIMER_MAX_TIMEOUT_TICKS", "group__MODEL__COMMON.html#ga9489713e922971f67182e66c09f340fb", null ],
    [ "MODEL_TIMER_PERIOD_MS_GET", "group__MODEL__COMMON.html#gaf14470beb9187a64eb38aca4647cda17", null ],
    [ "MODEL_TIMER_PERIOD_US_GET", "group__MODEL__COMMON.html#ga55c2d63ec009543a177683d38681b33d", null ],
    [ "MODEL_TIMER_TICKS_GET_MS", "group__MODEL__COMMON.html#ga7f1c3754e43853a3b3b027d1f4783cfd", null ],
    [ "MODEL_TIMER_TICKS_GET_US", "group__MODEL__COMMON.html#ga3b991da8c840c2a6b889171c6fac5fb8", null ],
    [ "model_timer_mode_t", "group__MODEL__COMMON.html#ga4895c421195a81870d74ef70492f31ac", [
      [ "MODEL_TIMER_MODE_SINGLE_SHOT", "group__MODEL__COMMON.html#gga4895c421195a81870d74ef70492f31aca690db2dacefd34a5e168b2c90fb1dd1b", null ],
      [ "MODEL_TIMER_MODE_REPEATED", "group__MODEL__COMMON.html#gga4895c421195a81870d74ef70492f31aca9479bf72955b47c9ab4aac88a9c39a24", null ]
    ] ],
    [ "model_transition_time_decode", "group__MODEL__COMMON.html#ga5f7fa660077d8f8986155f5cb5286051", null ],
    [ "model_transition_time_encode", "group__MODEL__COMMON.html#ga1437ea6f148bfa7e0c23f8d7b86c681e", null ],
    [ "model_transition_time_is_valid", "group__MODEL__COMMON.html#gabad56aed49ffdd7dde58f547242ea677", null ],
    [ "model_delay_decode", "group__MODEL__COMMON.html#ga0ec5930deac0a24d909b06a57e28af47", null ],
    [ "model_delay_encode", "group__MODEL__COMMON.html#gae8fde189b198b0c8db6ca4698d854b4d", null ],
    [ "model_tid_validate", "group__MODEL__COMMON.html#ga53584c90f74a8b74c827728a74a5ba42", null ],
    [ "model_transaction_is_new", "group__MODEL__COMMON.html#ga962dac814ccfe7bca36c7411085be96c", null ],
    [ "model_timer_schedule", "group__MODEL__COMMON.html#gaef6bc8afd02d7992d3a0f5626f09aeb5", null ],
    [ "model_timer_abort", "group__MODEL__COMMON.html#ga39441f6165e544aa34255c94a6c04378", null ],
    [ "model_timer_elapsed_ticks_get", "group__MODEL__COMMON.html#ga3c446768bd0ad67bef410466c833f83c", null ],
    [ "model_timer_create", "group__MODEL__COMMON.html#gac5279042c3c95737265092bf467b4815", null ]
];