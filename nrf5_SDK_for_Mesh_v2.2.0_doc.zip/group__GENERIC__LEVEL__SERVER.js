var group__GENERIC__LEVEL__SERVER =
[
    [ "generic_level_server_state_cbs_t", "structgeneric__level__server__state__cbs__t.html", [
      [ "get_cb", "structgeneric__level__server__state__cbs__t.html#a2ac0868e3db4f31bb36d310859dacf01", null ],
      [ "set_cb", "structgeneric__level__server__state__cbs__t.html#ad87b9c0427991de363da1bc9256eee69", null ],
      [ "delta_set_cb", "structgeneric__level__server__state__cbs__t.html#a68279fb666d61d0c3b63eb77cbea4f45", null ],
      [ "move_set_cb", "structgeneric__level__server__state__cbs__t.html#a58809f3b4cc8c57c2d8db85b253f9d70", null ]
    ] ],
    [ "generic_level_server_callbacks_t", "structgeneric__level__server__callbacks__t.html", [
      [ "level_cbs", "structgeneric__level__server__callbacks__t.html#a6c0479544ca4c651b9565c90ded61082", null ]
    ] ],
    [ "generic_level_server_settings_t", "structgeneric__level__server__settings__t.html", [
      [ "force_segmented", "structgeneric__level__server__settings__t.html#a5700a1885b5eeb3e49f30b2732263cf5", null ],
      [ "transmic_size", "structgeneric__level__server__settings__t.html#abc99d83937828fab067c57f068b99b58", null ],
      [ "p_callbacks", "structgeneric__level__server__settings__t.html#aea8e2fd8815aed3cb794e9243b732448", null ]
    ] ],
    [ "generic_level_server_t", "struct____generic__level__server__t.html", [
      [ "model_handle", "struct____generic__level__server__t.html#aedc6c26509864725c1c90536ba8db86e", null ],
      [ "tid_tracker", "struct____generic__level__server__t.html#aa8b5646220780cf2bb67261af16fdf2e", null ],
      [ "settings", "struct____generic__level__server__t.html#add6a49bd2da48b60b24312a18de5d034", null ]
    ] ],
    [ "GENERIC_LEVEL_SERVER_MODEL_ID", "group__GENERIC__LEVEL__SERVER.html#gadd13ec2a402e9d24126064bcb2a0061d", null ],
    [ "generic_level_state_set_cb_t", "group__GENERIC__LEVEL__SERVER.html#ga5cfd5f37dad1c7ebd0eb4e513572f442", null ],
    [ "generic_level_state_get_cb_t", "group__GENERIC__LEVEL__SERVER.html#ga7ec9d3638d066596879d50697e37a476", null ],
    [ "generic_level_state_delta_set_cb_t", "group__GENERIC__LEVEL__SERVER.html#ga41baad83520dd962c6c2b70481c74106", null ],
    [ "generic_level_state_move_set_cb_t", "group__GENERIC__LEVEL__SERVER.html#ga3eebdfe304248bd6c0f93a32efb803ca", null ],
    [ "generic_level_server_init", "group__GENERIC__LEVEL__SERVER.html#gafd3db95ae4cd9831583fe782d1801c58", null ],
    [ "generic_level_server_status_publish", "group__GENERIC__LEVEL__SERVER.html#ga69fc7ecc1fb91e0fb5ad3641711992b7", null ]
];