var group__SERIAL__HANDLER__ACCESS =
[
    [ "serial_handler_access_rx", "group__SERIAL__HANDLER__ACCESS.html#ga28db6eebb188d60f749cd7f0c42f76a2", null ],
    [ "hal_lfclk_ppm_get", "group__SERIAL__HANDLER__ACCESS.html#ga8bab42d8eeb1a820b39922b0e4790f69", null ]
];