var group__NRF__MESH__CONFIG__PROV =
[
    [ "Provisioning Bearer Configuration", "group__NRF__MESH__CONFIG__PROV__BEARER.html", "group__NRF__MESH__CONFIG__PROV__BEARER" ],
    [ "NRF_MESH_PROV_LINK_TIMEOUT_MIN_US", "group__NRF__MESH__CONFIG__PROV.html#ga92607dc5a63e2fe2ca25b7aa636d03a0", null ]
];