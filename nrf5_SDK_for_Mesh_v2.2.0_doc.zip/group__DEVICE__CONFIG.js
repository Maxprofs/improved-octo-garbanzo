var group__DEVICE__CONFIG =
[
    [ "DEVICE_COMPANY_ID", "group__DEVICE__CONFIG.html#gacfe0c7bafaf028684887944549dd83e8", null ],
    [ "DEVICE_PRODUCT_ID", "group__DEVICE__CONFIG.html#gadaa5ccc36be6653c6ed4ce1eebbcc068", null ],
    [ "DEVICE_VERSION_ID", "group__DEVICE__CONFIG.html#ga14558ccfd338d33479057b9c3f240695", null ],
    [ "DEVICE_FEATURES", "group__DEVICE__CONFIG.html#ga2c5a5145417e623018952c514c452aab", null ]
];