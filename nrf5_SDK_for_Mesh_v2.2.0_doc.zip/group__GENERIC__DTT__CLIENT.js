var group__GENERIC__DTT__CLIENT =
[
    [ "generic_dtt_client_callbacks_t", "structgeneric__dtt__client__callbacks__t.html", [
      [ "dtt_status_cb", "structgeneric__dtt__client__callbacks__t.html#abd25cc007a14e7c515dea67e86b1e19d", null ],
      [ "ack_transaction_status_cb", "structgeneric__dtt__client__callbacks__t.html#a26b298f48ce79862eb88e12068fbd26f", null ],
      [ "periodic_publish_cb", "structgeneric__dtt__client__callbacks__t.html#af27802cc2306f6b828fe74d5d4e28c3d", null ]
    ] ],
    [ "generic_dtt_client_settings_t", "structgeneric__dtt__client__settings__t.html", [
      [ "timeout", "structgeneric__dtt__client__settings__t.html#a38c415c44a6303a10d7080fcab6758df", null ],
      [ "force_segmented", "structgeneric__dtt__client__settings__t.html#a0cb7a801b1506a6e6cdca4b246e60c28", null ],
      [ "transmic_size", "structgeneric__dtt__client__settings__t.html#ae2f690a51388ee2c1536c92cf799d553", null ],
      [ "p_callbacks", "structgeneric__dtt__client__settings__t.html#adf0a133624439d3626921725cb89bcd1", null ]
    ] ],
    [ "generic_dtt_client_msg_data_t", "uniongeneric__dtt__client__msg__data__t.html", [
      [ "set", "uniongeneric__dtt__client__msg__data__t.html#ad442ca9bbb2c294b7cdd014ff88c3d28", null ]
    ] ],
    [ "generic_dtt_client_t", "struct____generic__dtt__client__t.html", [
      [ "model_handle", "struct____generic__dtt__client__t.html#a6e5f6a70ca15b111da7d322d9b20221e", null ],
      [ "msg_pkt", "struct____generic__dtt__client__t.html#a9c6518ae66ee30fc9ad5dfb69dee56f0", null ],
      [ "access_message", "struct____generic__dtt__client__t.html#a679c19dcfe9eac96b72d68840ec16ae4", null ],
      [ "settings", "struct____generic__dtt__client__t.html#af8f70e98f157a6f569b78db272038ccc", null ]
    ] ],
    [ "GENERIC_DTT_CLIENT_MODEL_ID", "group__GENERIC__DTT__CLIENT.html#ga147de7195cd151d2950016adc0b60c8e", null ],
    [ "generic_dtt_state_status_cb_t", "group__GENERIC__DTT__CLIENT.html#gad80e3aede12db6282bf53fb87fba2bff", null ],
    [ "generic_dtt_client_init", "group__GENERIC__DTT__CLIENT.html#gac4d769f6dcf7b0d65374fa5ce6ee5a91", null ],
    [ "generic_dtt_client_set", "group__GENERIC__DTT__CLIENT.html#ga60759b31af8b08ebcdedd7fc8b757861", null ],
    [ "generic_dtt_client_set_unack", "group__GENERIC__DTT__CLIENT.html#ga747a657402f73e64dec6813aa12d8a54", null ],
    [ "generic_dtt_client_get", "group__GENERIC__DTT__CLIENT.html#gacf6ef4329f1e3245949d11d815368979", null ]
];