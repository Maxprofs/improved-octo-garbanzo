var group__APP__LEVEL =
[
    [ "set_transition_t", "structset__transition__t.html", [
      [ "required_delta", "structset__transition__t.html#ad7590f08ceec2e15d7c00c8214205c4b", null ],
      [ "initial_present_level", "structset__transition__t.html#a852f680ad49182c1905bb725a7cec4f4", null ]
    ] ],
    [ "move_transition_t", "structmove__transition__t.html", [
      [ "required_move", "structmove__transition__t.html#a005426af847220da958499c9802eb239", null ],
      [ "initial_present_level", "structmove__transition__t.html#a4f6b3d24c1fb05f421373818177e7b8c", null ]
    ] ],
    [ "app_level_state_t", "structapp__level__state__t.html", [
      [ "present_level", "structapp__level__state__t.html#a9cfc96b0b7c24bbde3021f1436313edb", null ],
      [ "target_level", "structapp__level__state__t.html#aecb13de21a22007aa52a7a8db6d680ef", null ],
      [ "transition_time_ms", "structapp__level__state__t.html#acf1b1907d06be4d0ab09c98a78973ec1", null ],
      [ "delay_ms", "structapp__level__state__t.html#a88d320136d103d879b515e767547634a", null ],
      [ "transition_type", "structapp__level__state__t.html#a8e6b52cc01ce8dc2da4cd500cb9bedbc", null ],
      [ "set", "structapp__level__state__t.html#a72310542bed40f430e0c2b2d280215e9", null ],
      [ "move", "structapp__level__state__t.html#a7e3a3a9798f475475979727659ee2114", null ],
      [ "params", "structapp__level__state__t.html#a09fa5b5fe46250e44ec642189799471c", null ]
    ] ],
    [ "app_level_server_t", "struct____app__level__server__t.html", [
      [ "server", "struct____app__level__server__t.html#a08a874df49812d330ab3d5a7bbfad154", null ],
      [ "timer", "struct____app__level__server__t.html#abc0018c8356562774ccd608e19713a1c", null ],
      [ "level_set_cb", "struct____app__level__server__t.html#ae87a409515f2427483ee5de46ddd3562", null ],
      [ "level_get_cb", "struct____app__level__server__t.html#ab097ab624d987a93ce5c514a844f2349", null ],
      [ "p_dtt_ms", "struct____app__level__server__t.html#a5b2e0765932b44a1f095ad8597cb456b", null ],
      [ "state", "struct____app__level__server__t.html#a59176a21f91103a6bbc78d0f942f595a", null ],
      [ "fsm", "struct____app__level__server__t.html#a2eff6737dd4093a70fb060dcbac7cc5c", null ]
    ] ],
    [ "APP_LEVEL_SERVER_DEF", "group__APP__LEVEL.html#gac56789efaaf045be4e437e489afe5da8", null ],
    [ "app_level_set_cb_t", "group__APP__LEVEL.html#ga33ab959610c17686da608cd4b75dddbe", null ],
    [ "app_level_get_cb_t", "group__APP__LEVEL.html#ga4f4ce7aa58018c33184f01591a02dcff", null ],
    [ "app_level_transition_type_t", "group__APP__LEVEL.html#gae03d974399d64a3c47b267705bb14902", [
      [ "TRANSITION_SET", "group__APP__LEVEL.html#ggae03d974399d64a3c47b267705bb14902a3bbc2579955bfa65f1b68b77cc52e809", null ],
      [ "TRANSITION_DELTA_SET", "group__APP__LEVEL.html#ggae03d974399d64a3c47b267705bb14902acb4f257e34eb8d955230266480eb9f79", null ],
      [ "TRANSITION_MOVE_SET", "group__APP__LEVEL.html#ggae03d974399d64a3c47b267705bb14902acb1361ddf2705d55f26bfc156621503b", null ],
      [ "TRANSITION_NONE", "group__APP__LEVEL.html#ggae03d974399d64a3c47b267705bb14902ab8c904f868adb58dfb472bbd975bbf97", null ]
    ] ],
    [ "app_level_current_value_publish", "group__APP__LEVEL.html#ga66fd0b45128a20456baed9990603f3f8", null ],
    [ "app_level_init", "group__APP__LEVEL.html#ga613d72797ca3d2ea8bfcbb91767b2e36", null ]
];