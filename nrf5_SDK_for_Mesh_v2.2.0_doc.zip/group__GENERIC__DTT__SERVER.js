var group__GENERIC__DTT__SERVER =
[
    [ "generic_dtt_server_state_cbs_t", "structgeneric__dtt__server__state__cbs__t.html", [
      [ "set_cb", "structgeneric__dtt__server__state__cbs__t.html#aa8c5573fcc8df1dbfe56250529ab67a4", null ],
      [ "get_cb", "structgeneric__dtt__server__state__cbs__t.html#a513ddc58714cd53c47be84f8df4d05bc", null ]
    ] ],
    [ "generic_dtt_server_callbacks_t", "structgeneric__dtt__server__callbacks__t.html", [
      [ "dtt_cbs", "structgeneric__dtt__server__callbacks__t.html#a4b2cacd9c444c53811484170d9fa0029", null ]
    ] ],
    [ "generic_dtt_server_settings_t", "structgeneric__dtt__server__settings__t.html", [
      [ "force_segmented", "structgeneric__dtt__server__settings__t.html#a4a0c768be11cb217db6266802db6b4a7", null ],
      [ "transmic_size", "structgeneric__dtt__server__settings__t.html#a60cf8634d86a28f719d4d01ba6079acb", null ],
      [ "p_callbacks", "structgeneric__dtt__server__settings__t.html#a1b1ce47de7ac0faa650791f1336cac8a", null ]
    ] ],
    [ "generic_dtt_server_t", "struct____generic__dtt__server__t.html", [
      [ "model_handle", "struct____generic__dtt__server__t.html#abb34760bf0540936afaa833cb606b38c", null ],
      [ "settings", "struct____generic__dtt__server__t.html#aaa4963fd3f8cedca4a4d34df2c3c2cfd", null ]
    ] ],
    [ "GENERIC_DTT_SERVER_MODEL_ID", "group__GENERIC__DTT__SERVER.html#ga35c2fb2b071c883ed615bec6fef6cc05", null ],
    [ "generic_dtt_state_set_cb_t", "group__GENERIC__DTT__SERVER.html#gac5853a9a745c8f0009bba860612b8a64", null ],
    [ "generic_dtt_state_get_cb_t", "group__GENERIC__DTT__SERVER.html#ga15f84e9b5f7be38d5d0355f3cfc874dc", null ],
    [ "generic_dtt_server_init", "group__GENERIC__DTT__SERVER.html#gaf6438f6f1f4aadcbb72868907a9133a0", null ],
    [ "generic_dtt_server_status_publish", "group__GENERIC__DTT__SERVER.html#ga2bccaf240c889de600fedf551582ad63", null ]
];