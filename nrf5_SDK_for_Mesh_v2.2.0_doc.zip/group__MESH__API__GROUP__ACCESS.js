var group__MESH__API__GROUP__ACCESS =
[
    [ "Access layer API", "group__ACCESS.html", "group__ACCESS" ],
    [ "Access layer configuration", "group__ACCESS__CONFIG.html", "group__ACCESS__CONFIG" ]
];