var group__MESH__OPT__GATT =
[
    [ "MESH_OPT_GATT_PROXY_EID", "group__MESH__OPT__GATT.html#ga52af8b0af132efaa80da630a6bbaf223", null ],
    [ "mesh_opt_gatt_proxy_set", "group__MESH__OPT__GATT.html#ga4be456ffaee586ab9266841b508541ea", null ],
    [ "mesh_opt_gatt_proxy_get", "group__MESH__OPT__GATT.html#gaf456741b6a3898b0da0c156ac0a977b9", null ]
];