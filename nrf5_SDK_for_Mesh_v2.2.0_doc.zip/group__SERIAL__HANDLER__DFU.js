var group__SERIAL__HANDLER__DFU =
[
    [ "serial_handler_dfu_init", "group__SERIAL__HANDLER__DFU.html#ga32a66ea811ab5b470d9736728ab256db", null ],
    [ "serial_handler_dfu_rx", "group__SERIAL__HANDLER__DFU.html#gad86a74f5bcef46d2fcc343452a319629", null ]
];