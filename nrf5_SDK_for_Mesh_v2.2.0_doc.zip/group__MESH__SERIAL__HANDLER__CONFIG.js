var group__MESH__SERIAL__HANDLER__CONFIG =
[
    [ "serial_handler_config_rx", "group__MESH__SERIAL__HANDLER__CONFIG.html#gadd7ba1d2d8cac6a56e231dae859ce305", null ]
];